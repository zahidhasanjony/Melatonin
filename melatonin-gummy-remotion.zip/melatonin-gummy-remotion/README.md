# Melatonin Gummy — Three.js + Remotion 3D Cartoon Short

Complete 173.87-second (`1080x1920`, 30 fps) **2D-characters-in-3D-worlds** Remotion + Three.js project synced to your uploaded ElevenLabs voiceover (`public/voiceover.mp3`) and exact pause-aligned SRT (`audio/melatonin-gummy-voiceover.srt`).

## Quick Start (Local)

```bash
npm install
npm run dev          # Preview interactively in Remotion Studio
npm run build        # Render 1080x1920 MP4 (or npm run build:2k for 1440x2560)
```

## Cloud Render (Ubuntu 24.04 GitHub Actions)

1. Push this folder to a GitHub repository (your `public/voiceover.mp3` is already included).
2. Open **Actions -> Render Melatonin Gummy 3D Short -> Run workflow**.
3. Run with `is_still: true` to inspect any frame (`0–5215`), or `is_still: false` to render the full WebGL 3D MP4 with voiceover + synced Foley SFX mixed automatically.
