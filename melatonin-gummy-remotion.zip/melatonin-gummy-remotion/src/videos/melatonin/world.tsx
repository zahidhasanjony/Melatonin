import React, { useMemo } from 'react';
import * as THREE from 'three';
import { FPS, getSceneAt, smootherstep } from './story';
import { PALETTES } from './lights';
import { HeroCard } from './cast';

function makeLabelTex(title: string, subtitle: string, bg = '#181822', fg = '#ff5c5c') {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 256;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 512, 256);
  ctx.strokeStyle = '#110e16';
  ctx.lineWidth = 14;
  ctx.strokeRect(8, 8, 496, 240);
  ctx.fillStyle = fg;
  ctx.font = '900 72px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(title, 256, subtitle ? 98 : 128);
  if (subtitle) {
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 36px sans-serif';
    ctx.fillText(subtitle, 256, 178);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export const MelatoninWorld: React.FC<{ frame: number }> = ({ frame }) => {
  const sec = frame / FPS;
  const scene = getSceneAt(frame);
  const pal = PALETTES[scene.palette];

  const sign10pm = useMemo(() => makeLabelTex('10:00 PM', '', '#181822', '#ff5c5c'), []);
  const sign88 = useMemo(() => makeLabelTex('88% WRONG', '2023 STUDY', '#d63034', '#fff284'), []);
  const signDose = useMemo(() => makeLabelTex('0.5 - 1 mg', '2 HRS BEFORE BED', '#241a34', '#ffd860'), []);
  const signMold = useMemo(() => makeLabelTex('MOLDY FOOD', 'CLICK TO WATCH', '#2c984e', '#fff284'), []);

  return (
    <group>
      <fog attach="fog" args={[pal.fogColor, 18, 120]} />

      {/* Ground floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[120, 120]} />
        <meshToonMaterial color={pal.hemiGround} />
      </mesh>

      {scene.id === 'S01_HOOK_FLOOD' && sec < 3.58 && (
        <group>
          <HeroCard position={[-0.9, 0, 0]} frame={frame} expr="deadpan" outfit="pajama" armPose="eat" />
          {/* Nightstand & 10:00 PM digital clock */}
          <mesh position={[1.2, 0.7, -0.3]}>
            <boxGeometry args={[1.4, 1.4, 1.0]} />
            <meshToonMaterial color="#7a4c34" />
          </mesh>
          <mesh position={[1.2, 1.72, -0.1]}>
            <planeGeometry args={[1.35, 0.68]} />
            <meshBasicMaterial map={sign10pm} />
          </mesh>
        </group>
      )}

      {scene.id === 'S01_HOOK_FLOOD' && sec >= 3.58 && (
        <group>
          {/* 3D Brain flooded by rising 60x purple hormone wave */}
          <mesh position={[0, 2.3, 0]}>
            <sphereGeometry args={[1.35, 24, 18]} />
            <meshToonMaterial color="#f2b8c6" />
          </mesh>
          <mesh position={[0, smootherstep((sec - 3.58) / 3.5) * 2.1, 0.4]}>
            <boxGeometry args={[14, 3.0, 4.0]} />
            <meshToonMaterial color="#a644e8" emissive="#6c22b8" emissiveIntensity={0.45} />
          </mesh>
        </group>
      )}

      {scene.id === 'S02_REVERSE_CLOCK' && (
        <group>
          <HeroCard position={[-0.8, 0, 0]} frame={frame} expr="groggy" outfit="pajama" />
          {/* Reverse-spinning internal clock */}
          <group position={[1.2, 2.2, -0.5]}>
            <mesh>
              <cylinderGeometry args={[1.1, 1.1, 0.2, 24]} />
              <meshToonMaterial color="#f4f0e8" />
            </mesh>
            <mesh rotation={[0, 0, sec * 5.0]} position={[0, 0, 0.14]}>
              <boxGeometry args={[0.12, 0.85, 0.06]} />
              <meshToonMaterial color="#ba3038" />
            </mesh>
          </group>
        </group>
      )}

      {scene.id === 'S03_DOSAGE_BARS' && (
        <group>
          {/* 0.3mg tiny golden bar vs 5, 10, 20mg purple towers */}
          <mesh position={[-2.1, 0.12, 0]}>
            <boxGeometry args={[0.7, 0.24, 0.7]} />
            <meshToonMaterial color="#ffd660" emissive="#ffb830" emissiveIntensity={0.6} />
          </mesh>
          {[
            { x: -0.7, h: 1.5 },
            { x: 0.7, h: 2.7 },
            { x: 2.1, h: 4.1 },
          ].map((b) => {
            const grow = sec >= 32.37 ? smootherstep((sec - 32.37) / 3.2) : 0.08;
            const hh = Math.max(0.1, b.h * grow);
            return (
              <mesh key={b.x} position={[b.x, hh / 2, 0]}>
                <boxGeometry args={[0.85, hh, 0.85]} />
                <meshToonMaterial color="#a848e8" />
              </mesh>
            );
          })}
        </group>
      )}

      {scene.id === 'S04_REM_NIGHTMARE' && (
        <group>
          <HeroCard position={[0, 0, 0]} frame={frame} expr={sec >= 46.5 ? 'shock' : 'wide_awake'} outfit="pajama" />
          {/* Surreal floating REM dream spheres */}
          {[-1.8, 0, 1.8].map((x, idx) => (
            <mesh key={x} position={[x, 3.2 + Math.sin(sec * 3 + idx) * 0.35, -1.2]}>
              <dodecahedronGeometry args={[0.68]} />
              <meshToonMaterial color="#b65cda" emissive="#7428a8" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>
      )}

      {scene.id === 'S05_ALARM_FOG' && (
        <group>
          <HeroCard position={[-0.5, 0, 0]} frame={frame} expr="groggy" outfit="day" />
          <mesh position={[1.4 + Math.sin(sec * 45) * 0.1, 1.8, 0]}>
            <cylinderGeometry args={[0.55, 0.55, 0.3, 18]} />
            <meshToonMaterial color="#e04848" />
          </mesh>
        </group>
      )}

      {scene.id === 'S06_RECEPTORS_NUMB' && (
        <group>
          {[-1.8, 0, 1.8].map((x, idx) => {
            const numb = smootherstep((sec - 69.5) / 4.5);
            return (
              <group key={x} position={[x, 1.2, 0]}>
                <mesh>
                  <boxGeometry args={[1.1, 1.1, 1.1]} />
                  <meshToonMaterial color={numb > 0.5 ? '#5c566e' : '#6ce0c4'} />
                </mesh>
                <mesh position={[0, 2.4 - ((frame * 0.08 + idx) % 2.2), 0]}>
                  <sphereGeometry args={[0.28, 14, 12]} />
                  <meshToonMaterial color="#b056f0" emissive="#8032c8" emissiveIntensity={0.5} />
                </mesh>
              </group>
            );
          })}
        </group>
      )}

      {scene.id === 'S07_FDA_STUDY' && (
        <group>
          {Array.from({ length: 15 }).map((_, i) => {
            const row = Math.floor(i / 5);
            const col = i % 5;
            return (
              <mesh key={i} position={[-2.0 + col * 1.0, 0.8 + row * 1.15, -1.0]}>
                <cylinderGeometry args={[0.26, 0.26, 0.8, 12]} />
                <meshToonMaterial color={i % 6 === 0 ? '#5eba80' : '#d64444'} />
              </mesh>
            );
          })}
          {sec >= 89.5 && (
            <mesh position={[0, 2.5, 0.6]}>
              <planeGeometry args={[3.2, 1.6]} />
              <meshBasicMaterial map={sign88} />
            </mesh>
          )}
        </group>
      )}

      {scene.id === 'S08_STARTING_GUN' && (
        <group>
          <HeroCard position={[-0.7, 0, 0]} frame={frame} expr={sec >= 109.6 ? 'shock' : 'deadpan'} outfit="starter" armPose="gun" />
          <mesh position={[1.4, 2.5, -0.5]} rotation={[0, 0, sec * 6 * Math.sin(sec * 2)]}>
            <torusGeometry args={[0.95, 0.16, 12, 24]} />
            <meshToonMaterial color="#ffd860" emissive="#ff9e32" emissiveIntensity={0.5} />
          </mesh>
        </group>
      )}

      {scene.id === 'S09_MIDNIGHT_2PM' && (
        <group>
          <HeroCard position={[-1.2, 0, 0]} frame={frame} expr="wide_awake" outfit="pajama" />
          <HeroCard position={[1.2, 0, 0]} frame={frame} expr="groggy" outfit="day" />
        </group>
      )}

      {scene.id === 'S10_SMALL_DOSE' && (
        <group>
          <mesh position={[0, 2.5, 0]}>
            <sphereGeometry args={[0.42, 18, 16]} />
            <meshToonMaterial color="#ffd860" emissive="#ffbc38" emissiveIntensity={0.8} />
          </mesh>
          <mesh position={[0, 1.1, 0]}>
            <planeGeometry args={[2.8, 1.4]} />
            <meshBasicMaterial map={signDose} />
          </mesh>
        </group>
      )}

      {scene.id === 'S11_SUNLIGHT_RESET' && (
        <group>
          <HeroCard position={[0, 0, 0]} frame={frame} expr={sec < 150.4 ? 'happy' : 'sleep'} outfit={sec < 150.4 ? 'sunny' : 'pajama'} />
          {sec < 150.4 && (
            <mesh position={[2.2, 4.2, -3.5]}>
              <sphereGeometry args={[1.1, 18, 16]} />
              <meshBasicMaterial color="#ffe87a" toneMapped={false} />
            </mesh>
          )}
        </group>
      )}

      {scene.id === 'S12_MOLDY_CTA' && (
        <group>
          <HeroCard position={[-0.7, 0, 0]} frame={frame} expr="shock" outfit="day" armPose="sandwich" />
          {sec >= 163.7 && (
            <mesh position={[0.2, 3.2, 0.3]}>
              <planeGeometry args={[3.2, 1.6]} />
              <meshBasicMaterial map={signMold} />
            </mesh>
          )}
        </group>
      )}
    </group>
  );
};
