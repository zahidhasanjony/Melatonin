/**
 * Exact 2D Bean-Headed Character Drawing Engine (600x1000 canvas, feet at y=975).
 * Dark plum ink (#241726), bean head h/w ~0.94, face brightness ~0.93, no blush,
 * eyes 0.26W apart, stick limbs, and expressive pose/face swaps.
 */
export type HeroExpr = 'deadpan' | 'groggy' | 'sleep' | 'shock' | 'wide_awake' | 'happy';
export type HeroOutfit = 'pajama' | 'day' | 'starter' | 'sunny';
export type ArmPose = 'rest' | 'eat' | 'gun' | 'sandwich';

export interface DrawHeroOpts {
  expr: HeroExpr;
  outfit: HeroOutfit;
  armPose: ArmPose;
  timeSec: number;
  isBlinking: boolean;
  dizzy?: boolean;
}

const INK = '#241726';
const FACE_WHITE = '#ededf0';

export function drawHero2D(ctx: CanvasRenderingContext2D, opts: DrawHeroOpts) {
  ctx.clearRect(0, 0, 600, 1000);
  const cx = 300;
  const bob = Math.sin(opts.timeSec * 3.5) * 12;
  const hipY = 670 - bob;

  ctx.save();
  ctx.strokeStyle = INK;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  // Stick legs
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.moveTo(cx - 32, hipY);
  ctx.lineTo(cx - 36, 970);
  ctx.moveTo(cx + 32, hipY);
  ctx.lineTo(cx + 36, 970);
  ctx.stroke();

  // Bean torso
  const torsoColors: Record<HeroOutfit, string> = {
    pajama: '#4a609e',
    day: '#448086',
    starter: '#ba3e3a',
    sunny: '#e48e3e',
  };
  ctx.beginPath();
  ctx.roundRect(cx - 74, 465 - bob, 148, 225, 58);
  ctx.fillStyle = torsoColors[opts.outfit];
  ctx.fill();
  ctx.lineWidth = 11;
  ctx.stroke();

  // Stick arms + props
  ctx.lineWidth = 13;
  ctx.beginPath();
  ctx.moveTo(cx - 70, 520 - bob);
  ctx.lineTo(cx - 116, 610 - bob);
  ctx.moveTo(cx + 70, 520 - bob);
  if (opts.armPose === 'eat') {
    ctx.lineTo(cx + 150, 440 - bob);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx + 154, 434 - bob, 22, 0, Math.PI * 2);
    ctx.fillStyle = '#b056f0';
    ctx.fill();
    ctx.lineWidth = 7;
    ctx.stroke();
  } else if (opts.armPose === 'gun') {
    ctx.lineTo(cx + 165, 420 - bob);
    ctx.stroke();
    ctx.fillStyle = '#3c3e4a';
    ctx.fillRect(cx + 155, 365 - bob, 24, 62);
    ctx.fillRect(cx + 155, 360 - bob, 86, 26);
    ctx.strokeRect(cx + 155, 360 - bob, 86, 26);
  } else if (opts.armPose === 'sandwich') {
    ctx.lineTo(cx + 165, 490 - bob);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx + 145, 515 - bob);
    ctx.lineTo(cx + 245, 515 - bob);
    ctx.lineTo(cx + 195, 425 - bob);
    ctx.closePath();
    ctx.fillStyle = '#e0b876';
    ctx.fill();
    ctx.lineWidth = 8;
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx + 195, 480 - bob, 24, 16, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#52bc4c';
    ctx.fill();
    ctx.stroke();
  } else {
    ctx.lineTo(cx + 116, 610 - bob);
    ctx.stroke();
  }

  // Bean head (h/w ~0.94)
  const headY = 345 - bob;
  ctx.beginPath();
  ctx.ellipse(cx, headY, 118, 111, 0, 0, Math.PI * 2);
  ctx.fillStyle = FACE_WHITE;
  ctx.fill();
  ctx.lineWidth = 11;
  ctx.stroke();

  // Eyes (0.26W apart = 61px)
  const eg = 30.5;
  const ey = headY - 6;
  ctx.fillStyle = INK;
  if (opts.isBlinking || opts.expr === 'sleep') {
    ctx.lineWidth = 7;
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(cx + d * eg - 16, ey);
      ctx.lineTo(cx + d * eg + 16, ey);
      ctx.stroke();
    }
  } else if (opts.expr === 'happy') {
    ctx.lineWidth = 8;
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.arc(cx + d * eg, ey + 6, 15, Math.PI * 1.1, Math.PI * 1.9);
      ctx.stroke();
    }
  } else if (opts.expr === 'shock' || opts.expr === 'wide_awake') {
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.arc(cx + d * eg, ey, 18, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.lineWidth = 6;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx + d * eg, ey, 6, 0, Math.PI * 2);
      ctx.fillStyle = INK;
      ctx.fill();
    }
  } else {
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.ellipse(cx + d * eg, ey, 10, 12, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    if (opts.expr === 'deadpan' || opts.expr === 'groggy') {
      const lidH = opts.expr === 'groggy' ? 20 : 14;
      ctx.fillStyle = FACE_WHITE;
      ctx.fillRect(cx - eg - 18, ey - 16, eg * 2 + 36, lidH);
      ctx.lineWidth = 6.5;
      for (const d of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(cx + d * eg - 15, ey - 16 + lidH);
        ctx.lineTo(cx + d * eg + 15, ey - 16 + lidH);
        ctx.stroke();
      }
    }
  }

  // Mouth
  const my = headY + 38;
  ctx.lineWidth = 7;
  if (opts.expr === 'happy') {
    ctx.beginPath();
    ctx.arc(cx, my - 4, 24, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.closePath();
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.stroke();
  } else if (opts.expr === 'shock') {
    ctx.beginPath();
    ctx.ellipse(cx, my + 4, 15, 22, 0, 0, Math.PI * 2);
    ctx.fillStyle = INK;
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.moveTo(cx - 20, my + 2);
    ctx.lineTo(cx + 20, my + 2);
    ctx.stroke();
  }

  ctx.restore();
}
