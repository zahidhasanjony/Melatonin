import React, { useMemo } from 'react';
import * as THREE from 'three';
import { Billboard } from '@react-three/drei';
import { ArmPose, drawHero2D, HeroExpr, HeroOutfit } from './toon';
import { FPS } from './story';

export const NOINK_LAYER = 1;

interface HeroCardProps {
  position: [number, number, number];
  frame: number;
  expr: HeroExpr;
  outfit: HeroOutfit;
  armPose?: ArmPose;
  heightMeters?: number;
}

export const HeroCard: React.FC<HeroCardProps> = ({
  position,
  frame,
  expr,
  outfit,
  armPose = 'rest',
  heightMeters = 2.0,
}) => {
  const timeSec = frame / FPS;
  const isBlinking = frame % 56 < 4;

  const texture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 1000;
    const ctx = canvas.getContext('2d')!;
    drawHero2D(ctx, { expr, outfit, armPose, timeSec, isBlinking });
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.needsUpdate = true;
    return tex;
  }, [expr, outfit, armPose, Math.floor(timeSec * 10), isBlinking]);

  return (
    <group position={position}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
        <circleGeometry args={[0.45, 20]} />
        <meshBasicMaterial color="#1d1528" transparent opacity={0.48} depthWrite={false} />
      </mesh>
      <Billboard follow position={[0, heightMeters / 2, 0]}>
        <mesh layers={NOINK_LAYER}>
          <planeGeometry args={[heightMeters * 0.6, heightMeters]} />
          <meshStandardMaterial map={texture} transparent alphaTest={0.2} roughness={0.85} side={THREE.DoubleSide} />
        </mesh>
      </Billboard>
    </group>
  );
};
