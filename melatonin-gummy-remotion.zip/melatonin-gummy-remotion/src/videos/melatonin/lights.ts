import { PaletteKey } from './story';

export interface LightPalette {
  skyTop: string;
  skyHorizon: string;
  fogColor: string;
  sunColor: string;
  sunIntensity: number;
  sunPos: [number, number, number];
  hemiSky: string;
  hemiGround: string;
}

export const PALETTES: Record<PaletteKey, LightPalette> = {
  night: {
    skyTop: '#1a1c42',
    skyHorizon: '#383060',
    fogColor: '#383060',
    sunColor: '#98a6ff',
    sunIntensity: 1.1,
    sunPos: [12, 18, 14],
    hemiSky: '#5862a8',
    hemiGround: '#241d38',
  },
  purple: {
    skyTop: '#341858',
    skyHorizon: '#702e8a',
    fogColor: '#702e8a',
    sunColor: '#e2a8ff',
    sunIntensity: 1.35,
    sunPos: [14, 15, 12],
    hemiSky: '#a864d8',
    hemiGround: '#2b1942',
  },
  morning: {
    skyTop: '#7e9abc',
    skyHorizon: '#c4ceda',
    fogColor: '#c4ceda',
    sunColor: '#fff2de',
    sunIntensity: 1.45,
    sunPos: [18, 22, 12],
    hemiSky: '#a8c0dc',
    hemiGround: '#545c70',
  },
  lab: {
    skyTop: '#2a4466',
    skyHorizon: '#60809e',
    fogColor: '#60809e',
    sunColor: '#eef6ff',
    sunIntensity: 1.4,
    sunPos: [10, 20, 16],
    hemiSky: '#8cb2d4',
    hemiGround: '#324256',
  },
  golden: {
    skyTop: '#8a6688',
    skyHorizon: '#ffc27c',
    fogColor: '#ffc27c',
    sunColor: '#FFB36B',
    sunIntensity: 1.55,
    sunPos: [6, 8, -20],
    hemiSky: '#ffcf9e',
    hemiGround: '#444380',
  },
  sun: {
    skyTop: '#448adc',
    skyHorizon: '#ffd692',
    fogColor: '#ffd692',
    sunColor: '#fff3cf',
    sunIntensity: 1.65,
    sunPos: [16, 18, 10],
    hemiSky: '#98c4f4',
    hemiGround: '#5e7850',
  },
  kitchen: {
    skyTop: '#22484e',
    skyHorizon: '#406a62',
    fogColor: '#406a62',
    sunColor: '#d8f4d4',
    sunIntensity: 1.35,
    sunPos: [12, 18, 14],
    hemiSky: '#6ea89c',
    hemiGround: '#243430',
  },
};
