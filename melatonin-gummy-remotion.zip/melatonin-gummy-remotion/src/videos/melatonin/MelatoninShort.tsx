import React, { useEffect } from 'react';
import * as THREE from 'three';
import { ThreeCanvas } from '@remotion/three';
import { useFrame, useThree } from '@react-three/fiber';
import { Bloom, EffectComposer, ToneMapping } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';
import { AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { cameraAt, FLASH_SECS, FPS, getSceneAt } from './story';
import { PALETTES } from './lights';
import { MelatoninWorld } from './world';
import { Captions } from './Captions';

const CameraRig: React.FC<{ frame: number }> = ({ frame }) => {
  const { camera } = useThree();
  useEffect(() => {
    camera.layers.enable(0);
    camera.layers.enable(1);
  }, [camera]);

  useFrame(() => {
    const pose = cameraAt(frame);
    camera.position.set(pose.pos[0], pose.pos[1], pose.pos[2]);
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.fov = pose.fov;
      camera.updateProjectionMatrix();
    }
    camera.lookAt(pose.look[0], pose.look[1], pose.look[2]);
    camera.rotateZ((pose.rollDeg * Math.PI) / 180);
  });
  return null;
};

export const MelatoninShort: React.FC<{ showCaptions?: boolean }> = ({ showCaptions = true }) => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const sec = frame / FPS;
  const scene = getSceneAt(frame);
  const pal = PALETTES[scene.palette];
  const isFlash = FLASH_SECS.some((ts) => Math.abs(sec - ts) < 0.06);

  return (
    <AbsoluteFill style={{ backgroundColor: pal.skyHorizon }}>
      <Audio src={staticFile('voiceover.mp3')} />
      <ThreeCanvas
        width={width}
        height={height}
        camera={{ fov: 42, near: 0.2, far: 200 }}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
      >
        <CameraRig frame={frame} />
        <hemisphereLight args={[pal.hemiSky, pal.hemiGround, 0.78]} />
        <directionalLight position={pal.sunPos} intensity={pal.sunIntensity} color={pal.sunColor} />
        <MelatoninWorld frame={frame} />
        <EffectComposer multisampling={4}>
          <Bloom mipmapBlur luminanceThreshold={1.0} intensity={0.5} radius={0.6} />
          <ToneMapping mode={ToneMappingMode.NEUTRAL} />
        </EffectComposer>
      </ThreeCanvas>
      {isFlash && <AbsoluteFill style={{ backgroundColor: '#ffffff', opacity: 0.78, pointerEvents: 'none' }} />}
      {showCaptions && <Captions />}
    </AbsoluteFill>
  );
};
