export const FPS = 30;
export const DURATION_SEC = 173.871;
export const TOTAL_FRAMES = Math.ceil(DURATION_SEC * FPS); // 5217 frames

export type PaletteKey = 'night' | 'purple' | 'morning' | 'lab' | 'golden' | 'sun' | 'kitchen';

export interface SceneShot {
  id: string;
  aSec: number;
  bSec: number;
  palette: PaletteKey;
  rollDeg: number;
  creepRate: number;
}

/**
 * 12 scenes mapped 1-to-1 to exact silence-detected SRT boundaries of public/voiceover.mp3.
 */
export const SCENES: SceneShot[] = [
  { id: 'S01_HOOK_FLOOD', aSec: 0.0, bSec: 10.41, palette: 'night', rollDeg: 3.5, creepRate: 0.0028 },
  { id: 'S02_REVERSE_CLOCK', aSec: 10.41, bSec: 23.89, palette: 'morning', rollDeg: -3.2, creepRate: 0.0024 },
  { id: 'S03_DOSAGE_BARS', aSec: 23.89, bSec: 38.75, palette: 'night', rollDeg: 2.8, creepRate: 0.0022 },
  { id: 'S04_REM_NIGHTMARE', aSec: 38.75, bSec: 50.06, palette: 'purple', rollDeg: -4.4, creepRate: 0.0032 },
  { id: 'S05_ALARM_FOG', aSec: 50.06, bSec: 59.48, palette: 'morning', rollDeg: 3.8, creepRate: 0.0026 },
  { id: 'S06_RECEPTORS_NUMB', aSec: 59.48, bSec: 75.57, palette: 'purple', rollDeg: -3.6, creepRate: 0.0024 },
  { id: 'S07_FDA_STUDY', aSec: 75.57, bSec: 97.96, palette: 'lab', rollDeg: 2.5, creepRate: 0.002 },
  { id: 'S08_STARTING_GUN', aSec: 97.96, bSec: 115.67, palette: 'golden', rollDeg: -4.2, creepRate: 0.003 },
  { id: 'S09_MIDNIGHT_2PM', aSec: 115.67, bSec: 130.21, palette: 'night', rollDeg: 3.0, creepRate: 0.0024 },
  { id: 'S10_SMALL_DOSE', aSec: 130.21, bSec: 141.77, palette: 'golden', rollDeg: -2.2, creepRate: 0.0022 },
  { id: 'S11_SUNLIGHT_RESET', aSec: 141.77, bSec: 155.84, palette: 'sun', rollDeg: 2.0, creepRate: 0.0022 },
  { id: 'S12_MOLDY_CTA', aSec: 155.84, bSec: 174.5, palette: 'kitchen', rollDeg: -3.5, creepRate: 0.0028 },
];

export const FLASH_SECS = [3.58, 109.6];
export const KICK_SECS = [3.58, 48.0, 59.48, 90.0, 109.6, 160.4];

export function smootherstep(t: number): number {
  const x = Math.max(0, Math.min(1, t));
  return x * x * x * (x * (x * 6 - 15) + 10);
}

export function getSceneAt(frame: number): SceneShot {
  const sec = frame / FPS;
  for (const s of SCENES) {
    if (sec >= s.aSec && sec < s.bSec) return s;
  }
  return SCENES[SCENES.length - 1];
}

export function getKickOffset(frame: number): { dx: number; dy: number; dRoll: number } {
  let dx = 0;
  let dy = 0;
  let dRoll = 0;
  for (const ts of KICK_SECS) {
    const dt = frame - Math.round(ts * FPS);
    if (dt >= 0 && dt < 7) {
      const sign = dt % 2 === 0 ? 1 : -1;
      const decay = 1 - dt / 7;
      dx += sign * 0.28 * decay;
      dy += sign * 0.18 * decay;
      dRoll += sign * 3.8 * decay;
    }
  }
  return { dx, dy, dRoll };
}

export function cameraAt(frame: number) {
  const s = getSceneAt(frame);
  const sec = frame / FPS;
  const u = smootherstep((sec - s.aSec) / Math.max(0.01, s.bSec - s.aSec));
  const local = frame - Math.round(s.aSec * FPS);
  const creep = 1 - Math.min(0.16, local * s.creepRate);
  const kick = getKickOffset(frame);

  const posX = (-1.4 + u * 2.8) + kick.dx;
  const posY = 2.6 + Math.sin(u * Math.PI) * 0.35 + kick.dy;
  const posZ = 8.4 - u * 1.4;

  return {
    pos: [posX, posY, posZ] as [number, number, number],
    look: [0, 2.0, 0] as [number, number, number],
    fov: 42 * creep,
    rollDeg: s.rollDeg + kick.dRoll,
  };
}
