import React from 'react';
import { Composition } from 'remotion';
import { MelatoninShort } from './videos/melatonin/MelatoninShort';
import { FPS, TOTAL_FRAMES } from './videos/melatonin/story';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="MelatoninGummyShort"
      component={MelatoninShort}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={1080}
      height={1920}
      defaultProps={{
        showCaptions: true,
      }}
    />
  );
};
