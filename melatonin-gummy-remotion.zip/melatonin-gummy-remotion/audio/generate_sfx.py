#!/usr/bin/env python3
"""Synthesizes 48 kHz Foley SFX accents synced to exact Melatonin Gummy SRT beats."""
import argparse
import math
import struct
import wave
from pathlib import Path

SR = 48000
DURATION = 173.871


def build_sfx(out_path: Path):
    n = int(SR * DURATION)
    buf = [0.0] * n
    impacts = [
        (3.58, 120.0, 0.35),
        (50.06, 980.0, 0.22),
        (59.48, 110.0, 0.30),
        (90.00, 140.0, 0.32),
        (109.60, 1200.0, 0.38),
        (160.40, 180.0, 0.26),
    ]
    for ts, freq, amp in impacts:
        s0 = int(ts * SR)
        for i in range(int(0.28 * SR)):
            idx = s0 + i
            if idx >= n:
                break
            dt = i / SR
            noise = ((((idx * 1664525 + 1013904223) >> 16) & 0x7FFF) / 16384.0 - 1.0)
            buf[idx] += (math.sin(2 * math.pi * freq * dt) * 0.6 + noise * 0.4) * math.exp(-dt * 18.0) * amp

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out_path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SR)
        pcm = bytearray()
        for v in buf:
            pcm += struct.pack("<h", int(max(-0.95, min(0.95, v)) * 32767))
        wf.writeframes(pcm)
    print(f"Wrote 48 kHz SFX bed to {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path("out/sfx.wav"))
    args = parser.parse_args()
    build_sfx(args.out)
