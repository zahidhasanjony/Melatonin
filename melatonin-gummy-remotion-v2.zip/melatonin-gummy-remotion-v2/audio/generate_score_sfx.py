#!/usr/bin/env python3
"""
Synthesizes a 173.87s 48 kHz warm marimba/kalimba ambient curiosity-gap score (-18 dB bed)
plus 25+ crisp Foley accents synced 0-3 frames ahead of major v2 storyboard beats.
"""
import argparse
import math
import struct
import wave
from pathlib import Path

SR = 48000
DURATION = 173.871
N = int(SR * DURATION)


def build_score_and_sfx(out_path: Path):
    buf = [0.0] * N

    # 1. Warm marimba/kalimba curiosity-gap pulse (108 BPM = 0.555s per beat)
    scale = [261.63, 293.66, 329.63, 392.00, 440.00, 392.00, 329.63, 293.66]
    step = 0.5555
    for b in range(int(DURATION / step)):
        t0 = b * step
        freq = scale[b % len(scale)] * (0.5 if b % 4 == 0 else 1.0)
        s0 = int(t0 * SR)
        for i in range(int(0.42 * SR)):
            idx = s0 + i
            if idx >= N:
                break
            dt = i / SR
            env = math.sin(min(1.0, dt / 0.012) * math.pi * 0.5) * math.exp(-dt * 7.5)
            buf[idx] += (math.sin(2 * math.pi * freq * dt) * 0.75 + math.sin(4 * math.pi * freq * dt) * 0.25) * env * 0.085

    # 2. 22+ Tactile Foley accents timed to v2 42-shot beats
    sfx_events = [
        (1.80, 520.0, 0.22, 0.14),   # gummy pop
        (3.52, 110.0, 0.42, 0.35),   # X-ray sweep + 60x bass flood
        (7.15, 90.0, 0.44, 0.40),    # 60x wave impact
        (16.90, 680.0, 0.24, 0.22),  # clock rewind ratchet
        (23.85, 880.0, 0.18, 0.25),  # 0.3mg golden chime
        (34.35, 160.0, 0.30, 0.22),  # 5mg tower thud
        (35.80, 140.0, 0.32, 0.22),  # 10mg tower thud
        (37.20, 115.0, 0.36, 0.26),  # 20mg tower slam
        (38.75, 220.0, 0.26, 0.30),  # underwater REM dive
        (48.00, 95.0, 0.42, 0.38),   # nightmare thunder
        (50.04, 1040.0, 0.28, 0.28), # 7:00 AM alarm ring
        (59.45, 105.0, 0.44, 0.32),  # Week 3 brick wall thud
        (68.55, 420.0, 0.24, 0.22),  # receptor shutter 1
        (71.20, 360.0, 0.26, 0.22),  # receptor shutter 2
        (74.45, 210.0, 0.30, 0.28),  # receptors numb power-down
        (89.95, 130.0, 0.44, 0.32),  # 88% wrong rubber stamp slam
        (92.40, 320.0, 0.26, 0.20),  # 3x bottle inflate pop
        (105.60, 740.0, 0.30, 0.24), # glass clock crack
        (109.55, 1350.0, 0.48, 0.28),# biological starting gun crack
        (115.65, 290.0, 0.24, 0.24), # circadian breaker panel buzz
        (130.20, 784.0, 0.20, 0.30), # 0.5-1mg irony chime
        (146.15, 659.0, 0.22, 0.36), # morning sunlight swell
        (160.35, 180.0, 0.36, 0.30), # moldy sandwich shock sting
    ]
    for ts, freq, amp, dur in sfx_events:
        s0 = int(ts * SR)
        for i in range(int(dur * SR)):
            idx = s0 + i
            if idx >= N:
                break
            dt = i / SR
            noise = ((((idx * 1664525 + 1013904223) >> 16) & 0x7FFF) / 16384.0 - 1.0)
            env = math.exp(-dt * (5.5 / dur))
            buf[idx] += (math.sin(2 * math.pi * freq * dt) * 0.65 + noise * 0.35) * env * amp

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out_path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SR)
        pcm = bytearray()
        for v in buf:
            pcm += struct.pack("<h", int(max(-0.95, min(0.95, v)) * 32767))
        wf.writeframes(pcm)
    print(f"Wrote 48 kHz v2 score + Foley SFX to {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path("out/score_sfx.wav"))
    args = parser.parse_args()
    build_score_and_sfx(args.out)
