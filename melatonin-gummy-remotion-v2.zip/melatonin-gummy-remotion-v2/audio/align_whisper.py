#!/usr/bin/env python3
"""
Runs faster-whisper on public/voiceover.mp3 during GitHub Actions to generate
zero-drift word-level timestamps in audio/words.json.
Falls back cleanly to the bundled pre-aligned audio/words.json if faster-whisper is absent.
"""
import json
from pathlib import Path

def main():
    mp3 = Path("public/voiceover.mp3")
    out = Path("audio/words.json")
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        print("faster-whisper not installed; keeping pre-aligned audio/words.json")
        return

    print("Running faster-whisper (base.en, int8) for exact word-level timestamps...")
    model = WhisperModel("base.en", device="cpu", compute_type="int8")
    segments, _ = model.transcribe(str(mp3), word_timestamps=True)
    words = []
    for seg in segments:
        if not seg.words:
            continue
        for w in seg.words:
            tok = w.word.strip()
            if tok:
                words.append({"w": tok, "s": round(float(w.start), 3), "e": round(float(w.end), 3)})
    if len(words) > 100:
        out.write_text(json.dumps(words, indent=2), encoding="utf-8")
        print(f"Updated {out} with {len(words)} exact Whisper-aligned words.")
    else:
        print("Whisper returned too few words; keeping pre-aligned audio/words.json")

if __name__ == "__main__":
    main()
