# Master Upgrade Plan: Bringing `melatonin-gummy-3d` to Reference-Grade Quality

## 1. Forensic Diagnosis: Why `melatonin-gummy-3d.mp4` Looked Amateur

| Visual Pillar | Reference Videos (4 Benchmarks) | Current `melatonin-gummy-3d.mp4` | Root Cause to Fix | 
| ----- | ----- | ----- | ----- | 
| **3D Environments** | Fully enclosed, lived-in 3D rooms & landscapes (bedroom with striped rug, framed wall art, Edison bulb, wooden chair, side tables; Japanese office with green tile walls, drop ceiling, breaker box, skyscraper exterior). | Empty flat floor plane with 1–3 floating untextured primitives (horizontal grey pancake "clock" at `0:12`, floating red/green cylinders at `1:16`). | Replace primitive placeholders with modular, enclosed 3D room kits (walls, baseboards, windows, furniture, props) + Canvas2D painted textures. | 
| **World Outlines & Shading** | Crisp dark ink outlines (`#0b0a0c`) on all 3D geometry silhouettes & creases, paired with warm-key vs. cool-shadow two-tone cel shading and volumetric lamp cones. | Zero 3D ink outlines; flat solid-color surfaces with no surface texture, mortar, wood grain, or shadows. | Add inverted-hull (`BackSide`) cel-ink outline meshes on all 3D props + painted textures + fake volumetric cone meshes (`AdditiveBlending`) under lamps. | 
| **Character Lighting & Design** | Bright, high-contrast ivory-white bean heads (\~93% luma) even in dark rooms, distinct hair with highlights, collars/outfits, sitting/lying/peeking poses, and expressive animated limbs. | Muddy dark grey/brown bald character (`0:00`, `0:12`, `1:38`, `2:40`) frozen in one standing pose in the bottom-left corner. | Use an unlit-luma-protected custom `ShaderMaterial` for 2D character billboards (preserving `#ededf0` face brightness + warm inner rim) and add hair, pajamas/daywear, and multi-pose articulated rigs. | 
| **Visual Metaphors & Cutaways** | Tactile, memorable explainers: translucent blue X-ray body scan with glowing pink brain & neural pulse (*Idea Zone* `0:12`), vertical underwater sleep-depth meter + live EEG wave (`0:24`), corkboard with pinned cards & red string (`0:29`), breaker box labeled `HOPE / A/C / FRIENDS` (*Japan* `0:54`). | Floating purple dodecahedrons (`0:39`), bare untextured boxes (`1:00`), and giant cropped text boards (`88% WRONG` cut off at `1:30`, `MOLDY FOOD` cut off at `2:45`). | Build 5 dedicated signature explainer sets (X-ray brain flood, sleep-depth + EEG chart, docking-station airlock, corkboard/lab audit, and circadian breaker panel). | 
| **Pacing & Framing** | Visual beat or camera cut every **2.5–4.5 seconds** (40–55 shots per 3 min); foreground framing props; zero cropped text or clipped signs. | Only **12 static scenes** across `173.87s` (\~14.5s per shot); signs overflow camera frustum and clip off both edges. | Expand from 12 shots to **42 tightly choreographed shots** (3–4.5s each) with strict 9:16 frustum safe-zone bounds (`max width <= 2.6m` at `z=0`). | 
| **Audio Sync & Soundscape** | Razor-sharp word-to-visual sync (reactions hit 0–3 frames before the word) + energetic ducked background score + Foley every 2–3 seconds. | Scene cuts and captions drifted 2–4 seconds early after `1:35` (`Starting Gun` appeared during the CBD line; `0.5–1mg` appeared during irritability); dry audio with only 6 beeps. | Run forced alignment (`faster-whisper` or `whisper-timestamped`) inside GitHub Actions on `public/voiceover.mp3` to generate exact word timestamps, plus add a looping ambient curiosity-gap score (-18 dB) and 25+ Foley SFX. | 

## 2. Upgraded Rendering Architecture (Still 100% WebGL / SwANGLE Compatible)

### A. Enclosed 3D Architectural Sets (Zero Empty Voids)

Build 5 reusable, richly dressed 3D room/environment modules inside `src/videos/melatonin/sets/`:

1. **`BedroomSet.tsx`**: Warm dark-wood paneled walls, baseboard molding, concentric striped rug (echoing *Idea Zone*), wooden bed frame with rumpled blanket & pillow, nightstand with wood-grain texture, glowing red digital alarm clock (`10:00 PM` / `12:00 AM` / `7:00 AM`), framed wall portrait, window with venetian blinds + moonlight/sunlight shaft, and a hanging ceiling bulb with a soft additive volumetric light cone.

2. **`XRayBrainSet.tsx`**: Translucent cyan-blue X-ray silhouette of the seated/lying hero (modeled on *Idea Zone* `0:12–0:18`), revealing a detailed sculpted pink 3D brain, pineal gland emitter, glowing neural spine path, and rising translucent purple liquid shader with bubbles/foam.

3. **`SleepDepthChartSet.tsx`**: Modeled directly on *Idea Zone* `0:24–0:28` — a vertical underwater depth column (`AWAKE` -> `LIGHT SLEEP` -> `HYPER-REM` -> `DEEP SLEEP`) with sunbeams, floating dream icons, animated caustic light rings, and a live glowing cyan EEG waveform oscillating along the right margin.

4. **`ReceptorDockSet.tsx`**: Clean stylized sci-fi/biotech interior with glowing teal circular docking bays (`MT1 / MT2 RECEPTORS`), mechanical iris shutters that slam closed with warning lights when bombarded by oversized purple melatonin spheres, and a wall-mounted `SENSITIVITY` dial dropping from `100%` to `NUMB`.

5. **`LabAndBreakerSet.tsx`**: Wooden pharmacy/lab shelving with 25 individually outlined, labeled bottles (white caps, colored labels, magnifying glass inspection) + a wall-mounted **Circadian Control Panel** (modeled on *Japan*'s breaker box `0:54`) with labeled switches (`CORE TEMP`, `CORTISOL`, `SLEEP DRIVE`, `TIMING`) sparking out of sync.

### B. Crisp Cel-Shaded World Outlines (Fast on SwANGLE)

* Add a lightweight `OutlinedMesh` helper that renders every 3D prop with a `MeshToonMaterial` (2-tone gradient map + Canvas2D painted texture) plus a slightly scaled (`1.03–1.05x`) `BackSide` inverted-hull mesh in `#0b0a0c`.

* Inverted-hull outlines work reliably on CPU SwANGLE without expensive full-screen post-processing depth/normal edge passes, and give every chair, nightstand, bottle, and wall corner that exact hand-inked cartoon look.

### C. Upgraded 2D Character System (`toon.ts` + `HeroCard.tsx`)

* **Luma-Protected Shader**: Replace `meshStandardMaterial` on `HeroCard` with a custom `ShaderMaterial` that keeps the character's `#ededf0` white face bright and crisp in dark rooms while applying a subtle warm directional rim tint on the inner edge only (zero muddy grey faces).

* **Rich Character Design**: Add layered brown hair with a side part & highlight (like *Idea Zone*), collared pajama shirt with buttons & stripe pattern (night scenes), crisp casual sweater/shirt (daytime scenes), and slippers/shoes.

* **Full-Body Poses & Props**: Support `sitting_bed`, `lying_asleep`, `slumped_desk`, `walking_groggy`, `holding_bottle`, `peeking_clock`, `firing_starting_gun`, `tossing_trash`, `morning_stretch`, and `holding_moldy_sandwich`.

* **Expressive Micro-Acting**: Animated eyebrows, darting REM pupils, sweat drops, heavy purple under-eye bags, spinning dizzy stars, and 3-frame anticipation squash-and-stretch on shocks.

## 3. Upgraded 42-Shot Storyboard (Beat Change Every 3–4.5 Seconds)

| Block | Time Window | Shot Breakdown (3–4.5s Each) | Visual Metaphor & Camera Move | 
| ----- | ----- | ----- | ----- | 
| **Act 1: The 10 PM Hook** | `0:00 – 0:19` | **S01** (`0:00–0:03.5`) Bedroom CU: Hero sits on bed under warm bulb cone, pops glowing purple gummy (`10:00 PM` clock in foreground). **S02** (`0:03.5–0:07.0`) X-Ray sweep down body into glowing brain. **S03** (`0:07.0–0:10.4`) Purple `60X` tidal wave slams brain (7f shake). **S04** (`0:10.4–0:13.5`) Morning desk CU: Groggy hero slumps over coffee mug. **S05** (`0:13.5–0:16.9`) Montage swipe: calendar pages flipping (`MON -> TUE -> WED -> THU`) as hero pops gummy each night. **S06** (`0:16.9–0:19.8`) Wall clock CU: Gears grind and hands spin violently **counter-clockwise**. | Immediate hook + X-ray reveal + physical calendar/clock escalation. | 
| **Act 2: The Label Lie** | `0:19 – 0:39` | **S07** (`0:19.8–0:23.9`) POV glide onto nightstand melatonin bottle; magnifying glass highlights fine print. **S08** (`0:23.9–0:28.6`) Inside peaceful dark brain: tiny pineal gland releases one glowing golden `0.3 mg` droplet. **S09** (`0:28.6–0:32.3`) Bedroom window dims to starlight; light-switch clicks to `SHUT DOWN`. **S10** (`0:32.3–0:34.3`) Whip-pan back to nightstand bottle label. **S11** (`0:34.3–0:38.8`) 3D scale comparison on table: tiny `0.3 mg` drop dwarfed by slamming `5 mg`, `10 mg`, and towering `20 mg` gummy stacks. | Exact scale contrast grounded on a real wooden nightstand. | 
| **Act 3: Week 1 REM Storm** | `0:39 – 0:59` | **S12** (`0:38.8–0:44.8`) **Underwater Sleep-Depth Chart** (*Idea Zone* style): Hero sinks past `LIGHT SLEEP` into violent neon-purple `HYPER-REM` zone as EEG wave spikes wildly. **S13** (`0:44.8–0:50.1`) Dream nightmare shot: Hero's eyes dart in bed while giant surreal nightmare shadows & lightning loom behind headboard (7f shake). **S14** (`0:50.1–0:54.2`) Red twin-bell alarm clock explodes off nightstand (`7:00 AM`); X-ray shows purple hormone still sloshing in bloodstream. **S15** (`0:54.2–0:59.5`) Afternoon office/hallway walk: Hero drags feet under volumetric grey fog cloud with pulsing temple headache rings. | Signature underwater EEG chart + tactile alarm/bloodstream cutaway. | 
| **Act 4: Week 3 & Numb Receptors** | `0:59 – 1:17` | **S16** (`0:59.5–1:01.7`) Hero literally walks face-first into a 3D brick wall painted `WEEK 3` (7f shake). **S17** (`1:01.7–1:04.0`) Wide-eyed hero staring at ceiling in bed at `1:30 AM`. **S18** (`1:04.0–1:08.5`) Zoom into brain: sleek glowing teal `MELATONIN RECEPTOR` docking bays. **S19** (`1:08.5–1:14.5`) Purple gummies bombard bays; warning lights flash and heavy steel iris shutters slam down one by one. **S20** (`1:14.5–1:15.6`) Dark close-up on dimmed `NUMB` gauge. **S21** (`1:15.6–1:17.1`) Hero reaches back to nightstand and shakes out a **2nd gummy**. | Mechanical docking-station iris shutters give physical weight to desensitization. | 
| **Act 5: The 88% FDA Lab Audit** | `1:17 – 1:38` | **S22** (`1:17.1–1:24.5`) Pharmacy aisle glide: Bottle placed under `"DIETARY SUPPLEMENT"` cardboard sign vs. locked `"REGULATED DRUG"` glass cabinet. **S23** (`1:24.5–1:27.6`) Sleeping FDA inspector stamp desk (`UNVERIFIED`). **S24** (`1:27.6–1:32.3`) Lab table with 25 detailed gummy bottles; overhead scanner turns 22 of them red + crisp centered `88% MISLABELED` stamp (fits inside 80% safe width!). **S25** (`1:32.3–1:35.0`) One bottle inflates `3X` huge and pops its cap. **S26** (`1:35.0–1:38.0`) Another bottle dumps green leaves labeled `0 mg MELATONIN — ONLY CBD`. | Every single bottle has cap, outline, and label on a real lab bench. | 
| **Act 6: Starting Gun & Broken Rhythm** | `1:38 – 2:10` | **S27** (`1:38.0–1:41.6`) Calendar pages rip past (`MONTH 1 -> MONTH 6`). **S28** (`1:41.6–1:45.6`) Inside brain: healthy pineal gland still glowing (`STILL WORKS`). **S29** (`1:45.6–1:48.3`) Giant glass circadian clock cracks down the middle (`BROKEN TIMING`). **S30** (`1:48.3–1:51.4`) Track stadium cutaway: Hero holds **biological starting gun** (not a tranquilizer dart) and fires with muzzle flash (7f shake). **S31** (`1:51.4–1:55.6`) Starter fires randomly at `9 PM`, `1 AM`, `11 PM`, confusing runners on track. **S32** (`1:55.6–2:01.1`) **Circadian Breaker Panel** (*Japan* style): `CORE TEMP`, `CORTISOL`, and `SLEEP DRIVE` switches spark out of sync. **S33** (`2:01.1–2:06.3`) Split-room match cut: Wide-eyed hero staring at `12:00 AM` ceiling vs. face-planted on desk at `2:00 PM`. **S34** (`2:06.3–2:10.2`) Hero clutching stomach with dizzy orbiting stars & irritability steam puffs. | Replaces abstract shapes with track stadium + breaker box + split-room acting. | 
| **Act 7: The Irony, Reset & Moldy Food CTA** | `2:10 – 2:54` | **S35** (`2:10.2–2:14.7`) Golden-hour wooden table: single tiny glowing `0.5–1 mg` drop on a balance scale. **S36** (`2:14.7–2:19.3`) Clock reads `2 HRS BEFORE BED` with gentle golden countdown arc. **S37** (`2:19.3–2:21.8`) Miniature 3D airplane flies across globe (`JET LAG`). **S38** (`2:21.8–2:26.1`) Reassuring brain scan glowing warm green (`NO PERMANENT DAMAGE`). **S39** (`2:26.1–2:30.4`) Hero tosses purple bottle into bedroom trash bin, then opens curtains to golden morning sunbeams (`10 MIN SUNLIGHT`). **S40** (`2:30.4–2:35.8`) Cozy dark bedroom: hero sleeps peacefully with `Zzz` while clock ticks forward smoothly (`NO PILLS`). **S41** (`2:35.8–2:43.6`) Kitchen counter cut: Hero takes a bite of a sandwich, flips it over, and sees a glowing green fuzzy mold patch (eyes go huge, 7f shake). **S42** (`2:43.6–2:53.9`) Clean framed YouTube end-screen card (`NEXT VIDEO: MOLDY FOOD`) well inside 9:16 safe margins with animated pulsing pointer arrow. | Clean emotional resolution + high-CTR end-screen hook with zero clipping. | 

## 4. Exact Timing & Audio Mix Upgrade

1. **Zero-Drift Word Alignment**: Instead of estimating word durations proportionally inside pauses, run a lightweight Python `faster-whisper` (tiny/base English model, \~20 seconds on GitHub Actions CPU) step inside `render-from-zip.yml` on `public/voiceover.mp3` to output true word-level timestamps (`audio/words_exact.json`) and automatically map every scene cut to its exact trigger word.

2. **Ducked Ambient Score + Layered Foley**:

   * Synthesize or include a warm, subtle marimba/kalimba + soft pulse curiosity-gap instrumental loop (`-18 dB` under Steve's calm voiceover, automatically ducked `-4 dB` further during speech).

   * Add 25+ crisp Foley accents synced 0–3 frames ahead of visual hits: gummy pop, water flood whoosh, clock rewind ratchet, pill bottle rattle, deep thunder, twin-bell alarm, brick thud, metal iris clang, rubber stamp slam, starting gun crack, electrical breaker buzz, trash bin clank, and comedic record-scratch on the moldy sandwich.

## 5. Pre-Render Visual QA Gate (No More Blind 1-Hour Renders)

Before running a full 5,217-frame SwANGLE render on GitHub Actions:

1. Add a **`qa_sheet` workflow mode** that renders a **3x4 contact sheet of 12 key frames** (one from every major set, at `scale=0.5`, taking under 90 seconds total) and uploads `qa-contact-sheet.png`.

2. Inspect the contact sheet for 5 hard gates before committing to the full MP4:

   * Character faces stay bright ivory (`> 85%` luma) against dark rooms.

   * Every 3D room has walls, floor, ceiling/sky, and painted surface textures (zero empty voids).

   * Every 3D prop has crisp `#0b0a0c` outlines.

   * Zero signs, labels, or captions clip off the left/right edges of the 9:16 frame.

   * Every scene cut matches its exact spoken word in `words_exact.json`.