# Melatonin Gummy — v2 Reference-Grade 3D Cartoon Short

Upgraded v2 Three.js + Remotion project implementing all 5 pillars from `melatonin-pro-production-plan.md`:

- **5 Enclosed 3D Architectural & Explainer Sets**: `BedroomSet` (wood planks, striped rug, volumetric Edison bulb cone, portrait, nightstand, clock), `XRayBrainSet` (translucent blue X-ray cutaway + pink brain + 60x flood), `SleepDepthChartSet` (underwater sleep-depth meter + live EEG wave), `ReceptorDockSet` (biotech chamber + slamming steel iris shutters), and `LabAndBreakerSet` (25 outlined bottles + Japanese-office-style Circadian Breaker Panel + Starting Gun + Kitchen CTA).
- **Inverted-Hull `#0b0a0c` Cel Outlines** on all 3D props (SwANGLE-safe).
- **Luma-Protected 2D Character Rig**: Layered brown hair, collared outfits, multi-pose acting, and bright `#f2efe9` ivory faces that never turn muddy grey in dark rooms.
- **42-Shot Storyboard**: Dynamic camera glides every 3–4.5s with frustum-safe centered signs (zero clipping).
- **Exact Audio & QA Gate**: Auto `faster-whisper` word alignment, warm marimba/kalimba score + 23 Foley accents, and a fast **90-second `qa_sheet` mode** in `render-from-zip-v2.yml`.
