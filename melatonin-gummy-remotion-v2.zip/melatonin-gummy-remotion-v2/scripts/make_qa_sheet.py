#!/usr/bin/env python3
"""Stitches 12 rendered QA key frames into a clean 4x3 contact sheet for fast visual verification."""
import sys
from pathlib import Path
from PIL import Image, ImageDraw

def main():
    qa_dir = Path("out/qa_stills")
    imgs = sorted(qa_dir.glob("*.png"))
    if not imgs:
        sys.exit("No QA stills found in out/qa_stills")
    cols, rows = 4, 3
    sample = Image.open(imgs[0])
    tw, th = sample.size
    sheet = Image.new("RGB", (tw * cols, th * rows), (18, 16, 24))
    draw = ImageDraw.Draw(sheet)
    for idx, p in enumerate(imgs[: cols * rows]):
        im = Image.open(p).resize((tw, th))
        r, c = divmod(idx, cols)
        sheet.paste(im, (c * tw, r * th))
        draw.rectangle([c * tw + 8, r * th + 8, c * tw + 170, r * th + 40], fill=(16, 14, 22))
        draw.text((c * tw + 16, r * th + 16), p.stem, fill=(255, 232, 112))
    out_path = Path("out/qa-contact-sheet.png")
    sheet.save(out_path)
    print(f"Saved 4x3 QA contact sheet: {out_path} ({sheet.size[0]}x{sheet.size[1]})")

if __name__ == "__main__":
    main()
