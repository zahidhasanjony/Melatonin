import React, { useMemo } from 'react';
import * as THREE from 'three';

let sharedRamp: THREE.DataTexture | null = null;
function getToonRamp(): THREE.DataTexture {
  if (sharedRamp) return sharedRamp;
  const data = new Uint8Array([92, 90, 108, 255, 250, 246, 238, 255]);
  const tex = new THREE.DataTexture(data, 2, 1, THREE.RGBAFormat);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  sharedRamp = tex;
  return tex;
}

interface OutlinedBoxProps {
  args: [number, number, number];
  position?: [number, number, number];
  rotation?: [number, number, number];
  color?: string;
  map?: THREE.Texture;
  outlineThickness?: number;
  emissive?: string;
  emissiveIntensity?: number;
}

/**
 * 2-tone cel-shaded Box with crisp BackSide inverted-hull ink outline (#0b0a0c).
 * Works reliably on SwANGLE CPU WebGL with zero edge-pass artifacts.
 */
export const OutlinedBox: React.FC<OutlinedBoxProps> = ({
  args,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  color = '#ffffff',
  map,
  outlineThickness = 0.045,
  emissive = '#000000',
  emissiveIntensity = 0,
}) => {
  const ramp = useMemo(() => getToonRamp(), []);
  return (
    <group position={position} rotation={rotation}>
      <mesh>
        <boxGeometry args={args} />
        <meshToonMaterial color={color} map={map} gradientMap={ramp} emissive={emissive} emissiveIntensity={emissiveIntensity} />
      </mesh>
      <mesh>
        <boxGeometry args={[args[0] + outlineThickness, args[1] + outlineThickness, args[2] + outlineThickness]} />
        <meshBasicMaterial color="#0b0a0c" side={THREE.BackSide} />
      </mesh>
    </group>
  );
};

interface OutlinedCylinderProps {
  args: [number, number, number, number?];
  position?: [number, number, number];
  rotation?: [number, number, number];
  color?: string;
  map?: THREE.Texture;
  outlineScale?: number;
  emissive?: string;
  emissiveIntensity?: number;
}

export const OutlinedCylinder: React.FC<OutlinedCylinderProps> = ({
  args,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  color = '#ffffff',
  map,
  outlineScale = 1.06,
  emissive = '#000000',
  emissiveIntensity = 0,
}) => {
  const ramp = useMemo(() => getToonRamp(), []);
  return (
    <group position={position} rotation={rotation}>
      <mesh>
        <cylinderGeometry args={[args[0], args[1], args[2], args[3] ?? 20]} />
        <meshToonMaterial color={color} map={map} gradientMap={ramp} emissive={emissive} emissiveIntensity={emissiveIntensity} />
      </mesh>
      <mesh scale={[outlineScale, 1.03, outlineScale]}>
        <cylinderGeometry args={[args[0], args[1], args[2], args[3] ?? 20]} />
        <meshBasicMaterial color="#0b0a0c" side={THREE.BackSide} />
      </mesh>
    </group>
  );
};

/** Soft volumetric light cone under hanging bulbs & windows (Your Brain's Secret Idea Zone style) */
export const VolumetricCone: React.FC<{
  position: [number, number, number];
  radius?: number;
  height?: number;
  color?: string;
  opacity?: number;
}> = ({ position, radius = 2.6, height = 5.2, color = '#ffdfa0', opacity = 0.17 }) => {
  return (
    <mesh position={position}>
      <coneGeometry args={[radius, height, 28, 1, true]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={opacity}
        side={THREE.DoubleSide}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
};
