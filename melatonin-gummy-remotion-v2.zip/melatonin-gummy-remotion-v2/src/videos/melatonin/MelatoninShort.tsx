import React from 'react';
import * as THREE from 'three';
import { ThreeCanvas } from '@remotion/three';
import { useFrame, useThree } from '@react-three/fiber';
import { Bloom, EffectComposer, ToneMapping } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';
import { AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { cameraAt, FLASH_SECS, FPS, getShotAt } from './story';
import { PALETTES } from './lights';
import { BedroomSet } from './sets/BedroomSet';
import { XRayBrainSet } from './sets/XRayBrainSet';
import { SleepDepthChartSet } from './sets/SleepDepthChartSet';
import { ReceptorDockSet } from './sets/ReceptorDockSet';
import { LabAndBreakerSet } from './sets/LabAndBreakerSet';
import { Captions } from './Captions';

const CameraRig: React.FC<{ frame: number }> = ({ frame }) => {
  const { camera } = useThree();
  useFrame(() => {
    const pose = cameraAt(frame);
    camera.position.set(pose.pos[0], pose.pos[1], pose.pos[2]);
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.fov = pose.fov;
      camera.updateProjectionMatrix();
    }
    camera.lookAt(pose.look[0], pose.look[1], pose.look[2]);
    camera.rotateZ((pose.rollDeg * Math.PI) / 180);
  });
  return null;
};

export const MelatoninShort: React.FC<{ showCaptions?: boolean }> = ({ showCaptions = true }) => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const sec = frame / FPS;
  const shot = getShotAt(frame);
  const pal = PALETTES[shot.palette];
  const isFlash = FLASH_SECS.some((ts) => Math.abs(sec - ts) < 0.06);

  return (
    <AbsoluteFill style={{ backgroundColor: pal.bg }}>
      <Audio src={staticFile('voiceover.mp3')} />
      <ThreeCanvas
        width={width}
        height={height}
        camera={{ fov: 40, near: 0.2, far: 120 }}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
      >
        <color attach="background" args={[pal.bg]} />
        <fog attach="fog" args={[pal.fog, 10, 45]} />
        <CameraRig frame={frame} />

        <hemisphereLight args={[pal.hemiSky, pal.hemiGround, 0.85]} />
        <directionalLight position={pal.keyPos} intensity={pal.keyIntensity} color={pal.keyColor} />

        {shot.set === 'bedroom' && <BedroomSet frame={frame} shot={shot} />}
        {shot.set === 'xray' && <XRayBrainSet frame={frame} shot={shot} />}
        {shot.set === 'sleep_chart' && <SleepDepthChartSet frame={frame} shot={shot} />}
        {shot.set === 'receptors' && <ReceptorDockSet frame={frame} shot={shot} />}
        {shot.set === 'lab_breaker' && <LabAndBreakerSet frame={frame} shot={shot} />}

        <EffectComposer multisampling={4}>
          <Bloom mipmapBlur luminanceThreshold={1.0} intensity={0.48} radius={0.55} />
          <ToneMapping mode={ToneMappingMode.NEUTRAL} />
        </EffectComposer>
      </ThreeCanvas>

      {isFlash && <AbsoluteFill style={{ backgroundColor: '#ffffff', opacity: 0.78, pointerEvents: 'none' }} />}
      {showCaptions && <Captions />}
    </AbsoluteFill>
  );
};
