import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import wordsData from '../../../audio/words.json';

interface WordCue {
  w: string;
  s: number;
  e: number;
}

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const nowSec = frame / fps;
  const words = wordsData as WordCue[];

  let activeChunk = '';
  let chunkStartFrame = 0;

  for (let i = 0; i < words.length; i += 2) {
    const w1 = words[i];
    const w2 = words[i + 1];
    const start = w1.s;
    const end = w2 ? w2.e : w1.e;
    if (nowSec >= start && nowSec < end + 0.05) {
      activeChunk = w2 ? `${w1.w} ${w2.w}` : w1.w;
      chunkStartFrame = Math.floor(start * fps);
      break;
    }
  }

  if (!activeChunk) return null;

  const pop = spring({
    frame: Math.max(0, frame - chunkStartFrame),
    fps,
    config: { damping: 14, stiffness: 260, mass: 0.6 },
  });
  const scale = interpolate(pop, [0, 1], [0.86, 1.0]);

  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 360,
        display: 'flex',
        justifyContent: 'center',
        pointerEvents: 'none',
        padding: '0 64px',
      }}
    >
      <div
        style={{
          fontFamily: 'Impact, "Arial Black", "Noto Sans", sans-serif',
          fontWeight: 900,
          fontSize: 72,
          lineHeight: 1.08,
          color: '#ffffff',
          textAlign: 'center',
          transform: `scale(${scale})`,
          WebkitTextStroke: '14px #140f1a',
          paintOrder: 'stroke fill',
          textShadow: '0 8px 18px rgba(0,0,0,0.55)',
        }}
      >
        {activeChunk}
      </div>
    </div>
  );
};
