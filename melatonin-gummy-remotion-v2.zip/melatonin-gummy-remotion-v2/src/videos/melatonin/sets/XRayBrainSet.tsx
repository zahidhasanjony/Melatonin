import React, { useMemo } from 'react';
import { FPS, ShotBeat, smootherstep } from '../story';
import { OutlinedBox } from '../OutlinedMesh';
import { texSign } from '../textures';
import { HeroCard } from '../HeroCard';

interface SetProps {
  frame: number;
  shot: ShotBeat;
}

/**
 * Translucent Blue X-Ray Body & Brain Cutaway Set (modeled on Your Brain's Secret Idea Zone 0:12-0:18):
 * Shows glowing cyan X-ray silhouette, sculpted pink brain, horizontal scanner bar,
 * and either the 60x purple hormone flood, tiny 0.3mg golden droplet, or healthy green scan.
 */
export const XRayBrainSet: React.FC<SetProps> = ({ frame, shot }) => {
  const sec = frame / FPS;
  const u = smootherstep((sec - shot.aSec) / Math.max(0.01, shot.bSec - shot.aSec));
  const v = shot.variant;

  const badge60x = useMemo(() => texSign('60X FLOOD', 'HORMONE SURGE', '#3a1458', '#ffe868', '#ffffff'), []);
  const badge03 = useMemo(() => texSign('0.3 mg', 'NATURAL SIGNAL', '#16283c', '#ffd860', '#a8e4ff'), []);
  const badgeOk = useMemo(() => texSign('NO DAMAGE', 'BRAIN RECOVERS', '#163828', '#78f29e', '#ffffff'), []);

  const scanY = 3.2 - u * 2.6;

  return (
    <group>
      {/* Dark Enclosed Diagnostic Chamber */}
      <mesh position={[0, 3.0, -2.8]}>
        <planeGeometry args={[14, 8]} />
        <meshToonMaterial color="#0e1e2e" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[14, 14]} />
        <meshToonMaterial color="#122438" />
      </mesh>

      {/* Wooden Chair Silhouette */}
      <OutlinedBox args={[0.9, 0.1, 0.9]} position={[0, 0.72, -0.2]} color="#483020" />
      <OutlinedBox args={[0.9, 1.0, 0.1]} position={[0, 1.25, -0.6]} color="#483020" />

      {/* Translucent X-Ray Hero with Glowing Pink Brain */}
      <HeroCard position={[0, 0, 0.1]} frame={frame} expr="deadpan" outfit="pajama" pose="sitting" xrayMode heightMeters={2.2} />

      {/* Horizontal Cyan X-Ray Scanner Beam */}
      {v === 'scan_sweep' && (
        <mesh position={[0, scanY, 0.5]}>
          <planeGeometry args={[3.4, 0.08]} />
          <meshBasicMaterial color="#7ef4ff" toneMapped={false} />
        </mesh>
      )}

      {/* 60x Rising Purple Hormone Wave */}
      {v === 'flood_60x' && (
        <group>
          <mesh position={[0, u * 1.45, 0.45]}>
            <boxGeometry args={[4.4, 2.4, 0.6]} />
            <meshBasicMaterial color="#a644e8" transparent opacity={0.55} />
          </mesh>
          <mesh position={[0, 3.05, 0.6]}>
            <planeGeometry args={[1.9, 0.95]} />
            <meshBasicMaterial map={badge60x} />
          </mesh>
        </group>
      )}

      {/* Tiny Natural 0.3mg Golden Droplet */}
      {v === 'natural_03mg' && (
        <group>
          <mesh position={[0, 2.05 + Math.sin(sec * 4) * 0.08, 0.45]}>
            <sphereGeometry args={[0.14, 16, 14]} />
            <meshBasicMaterial color="#ffe066" toneMapped={false} />
          </mesh>
          <mesh position={[0, 3.05, 0.55]}>
            <planeGeometry args={[1.9, 0.95]} />
            <meshBasicMaterial map={badge03} />
          </mesh>
        </group>
      )}

      {/* Healthy Green Recovery Scan */}
      {(v === 'healthy_green' || v === 'still_works') && (
        <mesh position={[0, 3.05, 0.55]}>
          <planeGeometry args={[1.9, 0.95]} />
          <meshBasicMaterial map={badgeOk} />
        </mesh>
      )}
    </group>
  );
};
