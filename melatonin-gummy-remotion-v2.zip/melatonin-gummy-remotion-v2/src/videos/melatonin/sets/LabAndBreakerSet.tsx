import React, { useMemo } from 'react';
import { FPS, ShotBeat, smootherstep } from '../story';
import { OutlinedBox, OutlinedCylinder } from '../OutlinedMesh';
import { texBreakerPanel, texGreenTileWall, texSign, texWoodPlanks } from '../textures';
import { HeroCard } from '../HeroCard';

interface SetProps {
  frame: number;
  shot: ShotBeat;
}

/**
 * Enclosed Green-Tile Lab, Pharmacy Audit Shelf (25 Outlined Bottles),
 * Circadian Breaker Panel (The Job Nobody Wants in Japan style),
 * Track Stadium Starting Gun, Week 3 Brick Wall, and Kitchen Moldy-Food CTA.
 */
export const LabAndBreakerSet: React.FC<SetProps> = ({ frame, shot }) => {
  const sec = frame / FPS;
  const u = smootherstep((sec - shot.aSec) / Math.max(0.01, shot.bSec - shot.aSec));
  const v = shot.variant;

  const tileTex = useMemo(() => texGreenTileWall('#588f72', '#1d3228', 4, 3), []);
  const brickTex = useMemo(() => texGreenTileWall('#a85444', '#2c1816', 3, 3), []);
  const woodTex = useMemo(() => texWoodPlanks('#7c5232', 2, 2), []);

  const sign88 = useMemo(() => texSign('88% WRONG', '2023 US STUDY', '#c83236', '#ffe870', '#ffffff'), []);
  const sign3x = useMemo(() => texSign('3X DOSE!', 'OVERLABELED', '#a82838', '#ffe870', '#ffffff'), []);
  const signCbd = useMemo(() => texSign('0 mg MELATONIN', 'ONLY CBD', '#285c3c', '#ffe870', '#a8f8c4'), []);
  const signSupp = useMemo(() => texSign('SUPPLEMENT', 'NOT FDA TESTED', '#f2e6cf', '#1c1420', '#c83236'), []);
  const signWall = useMemo(() => texSign('WEEK 3', 'TOLERANCE WALL', '#3a1a1a', '#ffe870', '#ffffff'), []);
  const signMold = useMemo(() => texSign('MOLDY FOOD', 'CLICK TO WATCH', '#268846', '#ffe870', '#ffffff'), []);

  const breakerTex = useMemo(
    () =>
      texBreakerPanel([
        Math.floor(sec * 2) % 2 === 0,
        Math.floor(sec * 3 + 1) % 2 === 0,
        Math.floor(sec * 2.5) % 2 === 0,
        false,
      ]),
    [Math.floor(sec * 3)]
  );

  return (
    <group>
      {/* Enclosed Room Shell */}
      <mesh position={[0, 3.0, -2.5]}>
        <planeGeometry args={[12, 8]} />
        <meshToonMaterial map={v === 'week3_wall' ? brickTex : tileTex} color="#ffffff" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[12, 12]} />
        <meshToonMaterial map={woodTex} color="#ffffff" />
      </mesh>

      {/* Week 3 Brick Wall Impact */}
      {v === 'week3_wall' && (
        <group>
          <OutlinedBox args={[1.6, 3.2, 0.7]} position={[0.9, 1.6, 0]} map={brickTex} color="#ffffff" />
          <mesh position={[0.9, 2.55, 0.39]}>
            <planeGeometry args={[1.4, 0.7]} />
            <meshBasicMaterial map={signWall} />
          </mesh>
          <HeroCard position={[-0.6, 0, 0.2]} frame={frame} expr="shock" outfit="pajama" sweat />
        </group>
      )}

      {/* Pharmacy / FDA 25-Bottle Lab Shelves (Safe-Zone Width <= 2.3m!) */}
      {(v === 'supplement_shelf' || v === 'fda_unverified' || v === 'audit_88' || v === 'triple_dose' || v === 'zero_cbd') && (
        <group position={[0, 0, -0.8]}>
          {[0.8, 1.65, 2.5].map((sy, rIdx) => (
            <group key={sy} position={[0, sy, 0]}>
              <OutlinedBox args={[2.7, 0.1, 0.55]} color="#7a4c2a" />
              {[-0.96, -0.48, 0, 0.48, 0.96].map((bx, cIdx) => {
                const isGood = (rIdx * 5 + cIdx) % 7 === 0;
                const scaleTriple = v === 'triple_dose' && rIdx === 1 && cIdx === 2 ? 1 + u * 0.75 : 1;
                const bCol = v === 'zero_cbd' && rIdx === 1 && cIdx === 2 ? '#42a858' : isGood ? '#58b87c' : '#d24444';
                return (
                  <group key={bx} position={[bx, 0.05, 0]} scale={[scaleTriple, scaleTriple, scaleTriple]}>
                    <OutlinedCylinder args={[0.14, 0.14, 0.44, 14]} position={[0, 0.22, 0]} color={bCol} />
                    <OutlinedCylinder args={[0.1, 0.1, 0.1, 14]} position={[0, 0.48, 0]} color="#f4f2ee" />
                  </group>
                );
              })}
            </group>
          ))}
          {/* Centered Safe-Zone Banner (width = 2.05m -> NEVER clips on 9:16!) */}
          <mesh position={[0, 3.25, 0.5]}>
            <planeGeometry args={[2.05, 1.02]} />
            <meshBasicMaterial
              map={
                v === 'audit_88'
                  ? sign88
                  : v === 'triple_dose'
                  ? sign3x
                  : v === 'zero_cbd'
                  ? signCbd
                  : signSupp
              }
            />
          </mesh>
        </group>
      )}

      {/* Track Stadium Biological Starting Gun */}
      {(v === 'starting_gun' || v === 'scrambled_track') && (
        <group>
          <HeroCard position={[-0.65, 0, 0.2]} frame={frame} expr={v === 'starting_gun' ? 'shock' : 'worry'} outfit="starter" pose="gun" />
          <mesh position={[0.95, 2.25, -0.3]} rotation={[0, 0, sec * 6 * Math.sin(sec * 2.2)]}>
            <torusGeometry args={[0.68, 0.12, 12, 24]} />
            <meshToonMaterial color="#ffd860" emissive="#ff9c2a" emissiveIntensity={0.6} />
          </mesh>
        </group>
      )}

      {/* Wall-Mounted Circadian Breaker Panel (The Job Nobody Wants in Japan style) */}
      {v === 'breaker_panel' && (
        <group position={[0, 2.05, -1.2]}>
          <OutlinedBox args={[2.15, 2.15, 0.26]} color="#2b313a" />
          <mesh position={[0, 0, 0.15]}>
            <planeGeometry args={[1.95, 1.95]} />
            <meshBasicMaterial map={breakerTex} />
          </mesh>
        </group>
      )}

      {/* Kitchen Counter Moldy Food Bite + Safe-Width End-Screen CTA */}
      {(v === 'moldy_bite' || v === 'moldy_endcard') && (
        <group>
          <OutlinedBox args={[3.4, 1.0, 0.9]} position={[0, 0.5, -0.6]} color="#d8d4c8" />
          <HeroCard position={[-0.4, 0, 0.25]} frame={frame} expr="shock" outfit="day" pose="sandwich" sweat />
          {v === 'moldy_endcard' && (
            <mesh position={[0, 3.05, 0.45]} scale={[1 + Math.sin(sec * 6) * 0.03, 1 + Math.sin(sec * 6) * 0.03, 1]}>
              <planeGeometry args={[2.05, 1.02]} />
              <meshBasicMaterial map={signMold} />
            </mesh>
          )}
        </group>
      )}
    </group>
  );
};
