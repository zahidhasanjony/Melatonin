import React, { useMemo } from 'react';
import * as THREE from 'three';
import { FPS, ShotBeat, smootherstep } from '../story';
import { OutlinedBox, OutlinedCylinder, VolumetricCone } from '../OutlinedMesh';
import { texSign, texStripedRug, texWallPortrait, texWoodPlanks } from '../textures';
import { HeroCard } from '../HeroCard';

interface SetProps {
  frame: number;
  shot: ShotBeat;
}

/**
 * Enclosed 3D Bedroom Set (modeled on Your Brain's Secret Idea Zone):
 * Dark paneled walls, baseboard molding, concentric striped rug, hanging Edison bulb
 * with volumetric light cone, framed wall portrait, wooden chair/nightstand, and props.
 */
export const BedroomSet: React.FC<SetProps> = ({ frame, shot }) => {
  const sec = frame / FPS;
  const u = smootherstep((sec - shot.aSec) / Math.max(0.01, shot.bSec - shot.aSec));
  const v = shot.variant;

  const woodFloor = useMemo(() => texWoodPlanks('#5c3c24', 4, 4), []);
  const rugTex = useMemo(() => texStripedRug(), []);
  const portraitTex = useMemo(() => texWallPortrait(), []);
  const clk10 = useMemo(() => texSign('10:00 PM', '', '#14141c', '#ff5a5a'), []);
  const clk130 = useMemo(() => texSign('1:30 AM', '', '#14141c', '#ff5a5a'), []);
  const clk7 = useMemo(() => texSign('7:00 AM', 'ALARM', '#261414', '#ff5a5a', '#ffd060'), []);
  const bottleLbl = useMemo(() => texSign('MELATONIN', '10 MG', '#f4ead8', '#221828', '#8a34c4'), []);
  const calTex = useMemo(() => texSign('EVERY NIGHT', 'MON - SUN', '#f4ead8', '#1e1622', '#c83c3c'), []);
  const doseLbl = useMemo(() => texSign('0.5 - 1 mg', '2 HRS BEFORE', '#20182a', '#ffd860', '#ffffff'), []);

  const isBright = v === 'groggy_morning' || v === 'alarm_7am' || v === 'brain_fog' || v === 'sunlight_reset' || v === 'dizzy_cramps';
  const wallColor = v === 'sunlight_reset' ? '#7ea678' : isBright ? '#687b8c' : '#24302a';

  return (
    <group>
      {/* Enclosed Room Shell: Floor + Back Wall + Side Walls + Baseboard */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[14, 14]} />
        <meshToonMaterial map={woodFloor} color="#ffffff" />
      </mesh>
      <mesh position={[0, 3.6, -2.8]}>
        <planeGeometry args={[14, 7.6]} />
        <meshToonMaterial color={wallColor} />
      </mesh>
      <mesh position={[-4.2, 3.6, 0]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[12, 7.6]} />
        <meshToonMaterial color={wallColor} />
      </mesh>
      <mesh position={[4.2, 3.6, 0]} rotation={[0, -Math.PI / 2, 0]}>
        <planeGeometry args={[12, 7.6]} />
        <meshToonMaterial color={wallColor} />
      </mesh>
      {/* Wooden Baseboard Molding */}
      <OutlinedBox args={[8.6, 0.28, 0.12]} position={[0, 0.14, -2.74]} color="#3a2518" outlineThickness={0.03} />

      {/* Concentric Striped Rug (Idea Zone signature floor detail) */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.015, 0.2]}>
        <circleGeometry args={[2.5, 36]} />
        <meshBasicMaterial map={rugTex} />
      </mesh>

      {/* Framed Wall Portrait (right wall background) */}
      <mesh position={[1.45, 2.85, -2.72]}>
        <planeGeometry args={[0.95, 1.2]} />
        <meshBasicMaterial map={portraitTex} />
      </mesh>

      {/* Hanging Edison Bulb + Warm Volumetric Cone */}
      <OutlinedCylinder args={[0.025, 0.025, 1.6, 8]} position={[0, 4.9, 0]} color="#16141a" />
      <mesh position={[0, 4.05, 0]}>
        <sphereGeometry args={[0.16, 16, 12]} />
        <meshBasicMaterial color="#fff3c4" toneMapped={false} />
      </mesh>
      <VolumetricCone
        position={[0, 1.7, 0]}
        radius={2.3}
        height={4.7}
        color={v === 'sunlight_reset' ? '#ffe898' : v === 'nightmare' ? '#b85eff' : '#ffdfa0'}
        opacity={v === 'sunlight_reset' ? 0.24 : 0.16}
      />

      {/* Wooden Nightstand + Digital Clock + Bottle */}
      <OutlinedBox args={[1.1, 1.2, 0.9]} position={[1.15, 0.6, -0.45]} color="#6f4628" />
      <OutlinedBox args={[0.72, 0.36, 0.22]} position={[1.15, 1.38, -0.32]} color="#181822" />
      <mesh position={[1.15, 1.38, -0.19]}>
        <planeGeometry args={[0.64, 0.28]} />
        <meshBasicMaterial map={v === 'alarm_7am' ? clk7 : v === 'wide_awake_130am' ? clk130 : clk10} />
      </mesh>

      {/* Outlined Purple Melatonin Bottle on Nightstand */}
      <group position={[0.95, 1.2, -0.58]}>
        <OutlinedCylinder args={[0.16, 0.16, 0.42, 16]} position={[0, 0.21, 0]} color="#7a34b8" />
        <OutlinedCylinder args={[0.12, 0.12, 0.1, 16]} position={[0, 0.47, 0]} color="#f0eee8" />
        <mesh position={[0, 0.22, 0.17]}>
          <planeGeometry args={[0.26, 0.18]} />
          <meshBasicMaterial map={bottleLbl} />
        </mesh>
      </group>

      {/* Wall Clock (Reverse Spinning / Cracked / 2 Hrs Before) */}
      {(v === 'clock_reverse' || v === 'clock_cracked' || v === 'two_hours_before' || v === 'peaceful_sleep') && (
        <group position={[0, 2.45, -2.65]}>
          <OutlinedCylinder args={[0.82, 0.82, 0.12, 28]} rotation={[Math.PI / 2, 0, 0]} color="#f4eedc" />
          <OutlinedBox
            args={[0.08, 0.58, 0.05]}
            position={[0, 0, 0.08]}
            rotation={[0, 0, v === 'clock_reverse' ? sec * 6.5 : v === 'two_hours_before' ? -0.9 : -sec * 0.8]}
            color="#c63636"
            outlineThickness={0.02}
          />
          <OutlinedBox
            args={[0.1, 0.38, 0.05]}
            position={[0, 0, 0.1]}
            rotation={[0, 0, v === 'clock_reverse' ? sec * 1.6 : 0.4]}
            color="#1c1622"
            outlineThickness={0.02}
          />
        </group>
      )}

      {/* Calendar Montage Card */}
      {v === 'calendar_montage' && (
        <mesh position={[-1.05, 2.45, -1.6]} rotation={[0, 0.18, Math.sin(sec * 10) * 0.08]}>
          <planeGeometry args={[1.15, 0.72]} />
          <meshBasicMaterial map={calTex} />
        </mesh>
      )}

      {/* 0.3mg vs 5/10/20mg Dosage Towers Grounded on Wooden Table */}
      {v === 'dosage_towers' && (
        <group position={[-0.1, 0.0, 0.4]}>
          <OutlinedBox args={[2.9, 0.16, 1.0]} position={[0, 0.9, 0]} color="#7a4c2e" />
          {/* Tiny golden 0.3mg dot */}
          <OutlinedBox args={[0.26, 0.14, 0.26]} position={[-1.0, 1.05, 0]} color="#ffd860" emissive="#ffb830" emissiveIntensity={0.6} />
          {/* Towering 5 / 10 / 20 mg stacks */}
          {[
            { x: -0.35, h: 0.75 },
            { x: 0.35, h: 1.4 },
            { x: 1.05, h: 2.25 },
          ].map((b) => {
            const hh = Math.max(0.12, b.h * u);
            return <OutlinedBox key={b.x} args={[0.42, hh, 0.42]} position={[b.x, 0.98 + hh / 2, 0]} color="#a648e8" />;
          })}
        </group>
      )}

      {/* Small Dose Golden Scale */}
      {v === 'small_dose_scale' && (
        <group position={[0, 1.35, 0.1]}>
          <mesh position={[0, 0.55, 0]}>
            <sphereGeometry args={[0.26, 20, 16]} />
            <meshBasicMaterial color="#ffe070" toneMapped={false} />
          </mesh>
          <mesh position={[0, -0.1, 0.1]}>
            <planeGeometry args={[1.85, 0.92]} />
            <meshBasicMaterial map={doseLbl} />
          </mesh>
        </group>
      )}

      {/* Split Midnight vs 2 PM Hero Pair */}
      {v === 'split_midnight_2pm' && (
        <group>
          <HeroCard position={[-0.85, 0, 0.3]} frame={frame} expr="wide_awake" outfit="pajama" pose="sitting" heightMeters={1.85} />
          <HeroCard position={[0.85, 0, 0.3]} frame={frame} expr="groggy" outfit="day" pose="slump" heightMeters={1.85} dizzy />
        </group>
      )}

      {/* Primary Hero Character Acting inside Bedroom */}
      {v !== 'dosage_towers' && v !== 'clock_reverse' && v !== 'clock_cracked' && v !== 'bottle_closeup' && v !== 'small_dose_scale' && v !== 'split_midnight_2pm' && (
        <group>
          {/* Wooden Chair behind Hero (Idea Zone framing) */}
          <OutlinedBox args={[0.85, 0.1, 0.85]} position={[-0.25, 0.72, -0.15]} color="#8a5a32" />
          <OutlinedBox args={[0.85, 1.0, 0.1]} position={[-0.25, 1.25, -0.52]} color="#8a5a32" />
          <HeroCard
            position={[-0.25, 0, 0.1]}
            frame={frame}
            expr={
              v === 'groggy_morning' || v === 'brain_fog' || v === 'dizzy_cramps'
                ? 'groggy'
                : v === 'nightmare'
                ? 'rem_dart'
                : v === 'wide_awake_130am'
                ? 'wide_awake'
                : v === 'sunlight_reset'
                ? 'happy'
                : v === 'peaceful_sleep'
                ? 'sleep'
                : 'deadpan'
            }
            outfit={v === 'sunlight_reset' ? 'sunny' : isBright ? 'day' : 'pajama'}
            pose={
              v === 'eat_10pm' || v === 'second_gummy'
                ? 'eat'
                : v === 'sunlight_reset'
                ? 'stretch'
                : 'sitting'
            }
            dizzy={v === 'brain_fog' || v === 'dizzy_cramps'}
            sweat={v === 'nightmare' || v === 'alarm_7am'}
          />
        </group>
      )}
    </group>
  );
};
