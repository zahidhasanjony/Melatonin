import React, { useMemo } from 'react';
import { FPS, ShotBeat, smootherstep } from '../story';
import { OutlinedBox, OutlinedCylinder } from '../OutlinedMesh';
import { texGreenTileWall, texSign } from '../textures';

interface SetProps {
  frame: number;
  shot: ShotBeat;
}

/**
 * Enclosed Biotech Chamber with 3 Glowing Teal MT1/MT2 Melatonin Receptor Docking Bays
 * and mechanical steel iris shutters slamming shut under purple bombardment.
 */
export const ReceptorDockSet: React.FC<SetProps> = ({ frame, shot }) => {
  const sec = frame / FPS;
  const u = smootherstep((sec - shot.aSec) / Math.max(0.01, shot.bSec - shot.aSec));
  const v = shot.variant;

  const wallTex = useMemo(() => texGreenTileWall('#1e3a4c', '#0e1d28', 4, 3), []);
  const gaugeOpen = useMemo(() => texSign('RECEPTORS', 'ACTIVE 100%', '#142634', '#74f5dc', '#ffffff'), []);
  const gaugeNumb = useMemo(() => texSign('RECEPTORS', 'NUMB - SHUT', '#261420', '#ff6464', '#ffd060'), []);

  const shutterClose = v === 'docks_numb' ? 1.0 : v === 'docks_closing' ? u : 0.0;

  return (
    <group>
      {/* Enclosed Biotech Wall & Floor */}
      <mesh position={[0, 3.0, -2.5]}>
        <planeGeometry args={[12, 8]} />
        <meshToonMaterial map={wallTex} color="#ffffff" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[12, 12]} />
        <meshToonMaterial color="#162838" />
      </mesh>

      {/* Wall Sensitivity Status Display (Safe-Zone Width <= 2.1m) */}
      <mesh position={[0, 3.25, -2.35]}>
        <planeGeometry args={[2.1, 1.05]} />
        <meshBasicMaterial map={shutterClose > 0.55 ? gaugeNumb : gaugeOpen} />
      </mesh>

      {/* 3 Circular Melatonin Receptor Docking Bays */}
      {[-1.15, 0, 1.15].map((x, idx) => {
        const orbY = 3.2 - (((frame * 0.09 + idx * 1.1) % 2.3));
        return (
          <group key={x} position={[x, 0.7, 0]}>
            <OutlinedCylinder args={[0.45, 0.52, 0.9, 20]} position={[0, 0.45, 0]} color={shutterClose > 0.6 ? '#4e485c' : '#4ecab8'} />
            {/* Mechanical Steel Iris Shutter sliding closed */}
            {shutterClose > 0.05 && (
              <OutlinedBox
                args={[0.88, 0.24, 0.88]}
                position={[0, 0.96 + (1 - shutterClose) * 0.35, 0]}
                color="#383e4a"
              />
            )}
            {/* Bombarding Purple Melatonin Spheres */}
            {v !== 'docks_open' && (
              <mesh position={[0, orbY, 0]}>
                <sphereGeometry args={[0.2, 14, 12]} />
                <meshToonMaterial color="#c45cf8" emissive="#822cd4" emissiveIntensity={0.55} />
              </mesh>
            )}
          </group>
        );
      })}
    </group>
  );
};
