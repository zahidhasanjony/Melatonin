import React, { useMemo } from 'react';
import * as THREE from 'three';
import { FPS, ShotBeat, smootherstep } from '../story';
import { HeroCard } from '../HeroCard';
import { OutlinedBox } from '../OutlinedMesh';

interface SetProps {
  frame: number;
  shot: ShotBeat;
}

/**
 * Vertical Underwater Sleep-Depth Chart + Live EEG Waveform
 * (modeled directly on Your Brain's Secret Idea Zone 0:24-0:28),
 * plus Golden-Hour Jet-Lag Airplane variant.
 */
export const SleepDepthChartSet: React.FC<SetProps> = ({ frame, shot }) => {
  const sec = frame / FPS;
  const u = smootherstep((sec - shot.aSec) / Math.max(0.01, shot.bSec - shot.aSec));

  const chartTex = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 1024;
    const ctx = c.getContext('2d')!;
    const grad = ctx.createLinearGradient(0, 0, 0, 1024);
    grad.addColorStop(0, '#1e5274');
    grad.addColorStop(0.32, '#1c3e68');
    grad.addColorStop(0.62, '#4a2278');
    grad.addColorStop(1, '#12122e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 1024);

    // Depth scale ticks & stage labels
    ctx.strokeStyle = 'rgba(255,220,160,0.65)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(64, 90);
    ctx.lineTo(64, 930);
    ctx.stroke();

    const stages = [
      { y: 150, label: 'AWAKE', col: '#ffffff' },
      { y: 360, label: 'LIGHT SLEEP', col: '#a8e2ff' },
      { y: 600, label: 'HYPER-REM', col: '#f49eff' },
      { y: 860, label: 'DEEP SLEEP', col: '#84a2ff' },
    ];
    ctx.font = '900 32px sans-serif';
    stages.forEach((st) => {
      ctx.fillStyle = st.col;
      ctx.fillText(st.label, 92, st.y);
      ctx.strokeStyle = 'rgba(255,255,255,0.22)';
      ctx.setLineDash([12, 12]);
      ctx.beginPath();
      ctx.moveTo(64, st.y + 18);
      ctx.lineTo(480, st.y + 18);
      ctx.stroke();
      ctx.setLineDash([]);
    });

    // Live-style EEG squiggle on right margin
    ctx.strokeStyle = '#7effe8';
    ctx.lineWidth = 5;
    ctx.beginPath();
    for (let y = 120; y < 900; y += 6) {
      const amp = y > 480 && y < 710 ? 38 : 10;
      const x = 425 + Math.sin(y * 0.19) * amp;
      if (y === 120) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);

  if (shot.variant === 'jet_lag_plane') {
    const px = -1.6 + u * 3.2;
    return (
      <group>
        <mesh position={[0, 2.5, -2.6]}>
          <planeGeometry args={[14, 9]} />
          <meshToonMaterial color="#7d5a7c" />
        </mesh>
        {/* Stylized 3D Airplane gliding across sunset */}
        <group position={[px, 2.35 + Math.sin(sec * 3) * 0.12, 0]} rotation={[0, 0, -0.06]}>
          <OutlinedBox args={[1.45, 0.28, 0.32]} color="#f4f2ee" />
          <OutlinedBox args={[0.42, 0.08, 1.5]} position={[0.05, 0, 0]} color="#d8dee8" />
          <OutlinedBox args={[0.25, 0.42, 0.08]} position={[-0.6, 0.24, 0]} color="#d64444" />
        </group>
      </group>
    );
  }

  // Hero sinking from AWAKE down into neon-purple HYPER-REM zone
  const diveY = 2.6 - u * 1.45;
  return (
    <group>
      <mesh position={[0, 2.1, -1.6]}>
        <planeGeometry args={[4.4, 8.8]} />
        <meshBasicMaterial map={chartTex} />
      </mesh>
      <HeroCard
        position={[0, diveY, 0.2]}
        frame={frame}
        expr={u > 0.45 ? 'rem_dart' : 'sleep'}
        outfit="pajama"
        pose="sitting"
        heightMeters={1.55}
        rimTint="#d6ecff"
      />
    </group>
  );
};
