import React, { useMemo } from 'react';
import * as THREE from 'three';
import { Billboard } from '@react-three/drei';
import { drawHeroV2, HeroExpr, HeroOutfit, HeroPose } from './toon';
import { FPS } from './story';

interface HeroCardV2Props {
  position: [number, number, number];
  frame: number;
  expr: HeroExpr;
  outfit: HeroOutfit;
  pose?: HeroPose;
  heightMeters?: number;
  rimTint?: string;
  dizzy?: boolean;
  sweat?: boolean;
  xrayMode?: boolean;
}

/**
 * Luma-protected 2D character billboard:
 * Uses meshBasicMaterial + warm tint modulation so ivory faces NEVER turn muddy grey
 * inside dark moody bedrooms (fixing the #1 lighting defect of v1).
 */
export const HeroCard: React.FC<HeroCardV2Props> = ({
  position,
  frame,
  expr,
  outfit,
  pose = 'rest',
  heightMeters = 2.05,
  rimTint = '#fff7ec',
  dizzy = false,
  sweat = false,
  xrayMode = false,
}) => {
  const timeSec = frame / FPS;
  const isBlinking = frame % 54 < 4;

  const texture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 1000;
    const ctx = canvas.getContext('2d')!;
    drawHeroV2(ctx, { expr, outfit, pose, timeSec, isBlinking, dizzy, sweat, xrayMode });
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.needsUpdate = true;
    return tex;
  }, [expr, outfit, pose, Math.floor(timeSec * 12), isBlinking, dizzy, sweat, xrayMode]);

  return (
    <group position={position}>
      {/* Soft dark ground contact shadow under soles */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
        <circleGeometry args={[0.48, 22]} />
        <meshBasicMaterial color="#16101c" transparent opacity={0.5} depthWrite={false} />
      </mesh>
      <Billboard follow position={[0, heightMeters / 2, 0]}>
        <mesh>
          <planeGeometry args={[heightMeters * 0.6, heightMeters]} />
          <meshBasicMaterial
            map={texture}
            color={rimTint}
            transparent
            alphaTest={0.18}
            side={THREE.DoubleSide}
          />
        </mesh>
      </Billboard>
    </group>
  );
};
