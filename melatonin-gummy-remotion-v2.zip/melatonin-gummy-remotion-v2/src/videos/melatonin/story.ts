export const FPS = 30;
export const DURATION_SEC = 173.871;
export const TOTAL_FRAMES = Math.ceil(DURATION_SEC * FPS); // 5217 frames

export type SetType =
  | 'bedroom'
  | 'xray'
  | 'sleep_chart'
  | 'receptors'
  | 'lab_breaker';

export type PaletteKey = 'bedroom_night' | 'xray_blue' | 'morning_warm' | 'purple_rem' | 'receptor_tech' | 'lab_tile' | 'golden_track' | 'sun_reset' | 'kitchen_cta';

export interface ShotBeat {
  id: string;
  aSec: number;
  bSec: number;
  set: SetType;
  variant: string;
  palette: PaletteKey;
  camFrom: [number, number, number];
  camTo: [number, number, number];
  lookAt: [number, number, number];
  fov: number;
  rollDeg: number;
  creep: number;
}

/**
 * 42 tightly choreographed shots (3.0 to 4.5s each) matching the v2 Master Production Plan.
 * Every shot uses enclosed 3D sets, smooth camera glides, and frustum-safe framing.
 */
export const SHOTS: ShotBeat[] = [
  // ACT 1: The 10 PM Hook (0:00 - 0:19.8)
  { id: 'S01', aSec: 0.0, bSec: 3.55, set: 'bedroom', variant: 'eat_10pm', palette: 'bedroom_night', camFrom: [0.0, 2.3, 6.2], camTo: [0.2, 2.2, 5.2], lookAt: [0, 1.85, 0], fov: 40, rollDeg: 2.0, creep: 0.0025 },
  { id: 'S02', aSec: 3.55, bSec: 6.9, set: 'xray', variant: 'scan_sweep', palette: 'xray_blue', camFrom: [-0.6, 2.1, 6.0], camTo: [0.2, 2.2, 5.2], lookAt: [0, 1.9, 0], fov: 38, rollDeg: -2.5, creep: 0.003 },
  { id: 'S03', aSec: 6.9, bSec: 10.41, set: 'xray', variant: 'flood_60x', palette: 'purple_rem', camFrom: [0.2, 2.4, 5.6], camTo: [-0.2, 2.5, 4.7], lookAt: [0, 2.1, 0], fov: 40, rollDeg: 3.5, creep: 0.0035 },
  { id: 'S04', aSec: 10.41, bSec: 13.56, set: 'bedroom', variant: 'groggy_morning', palette: 'morning_warm', camFrom: [0.8, 2.2, 5.8], camTo: [0.3, 2.1, 5.0], lookAt: [0, 1.8, 0], fov: 39, rollDeg: -2.0, creep: 0.0025 },
  { id: 'S05', aSec: 13.56, bSec: 16.94, set: 'bedroom', variant: 'calendar_montage', palette: 'bedroom_night', camFrom: [-0.9, 2.4, 6.1], camTo: [0.7, 2.3, 5.3], lookAt: [0, 1.9, 0], fov: 40, rollDeg: 2.5, creep: 0.0025 },
  { id: 'S06', aSec: 16.94, bSec: 19.82, set: 'bedroom', variant: 'clock_reverse', palette: 'bedroom_night', camFrom: [0.0, 2.5, 5.2], camTo: [0.0, 2.5, 4.2], lookAt: [0, 2.4, -2.5], fov: 36, rollDeg: -4.0, creep: 0.004 },

  // ACT 2: The Label Lie (0:19.8 - 0:38.8)
  { id: 'S07', aSec: 19.82, bSec: 23.89, set: 'bedroom', variant: 'bottle_closeup', palette: 'bedroom_night', camFrom: [1.2, 2.1, 4.6], camTo: [1.0, 1.9, 3.6], lookAt: [1.1, 1.65, -0.4], fov: 36, rollDeg: 2.0, creep: 0.003 },
  { id: 'S08', aSec: 23.89, bSec: 28.61, set: 'xray', variant: 'natural_03mg', palette: 'xray_blue', camFrom: [0.0, 2.3, 5.6], camTo: [0.0, 2.3, 4.7], lookAt: [0, 2.2, 0], fov: 38, rollDeg: 1.5, creep: 0.002 },
  { id: 'S09', aSec: 28.61, bSec: 32.37, set: 'bedroom', variant: 'dark_signal', palette: 'bedroom_night', camFrom: [-1.1, 2.4, 6.4], camTo: [-0.4, 2.3, 5.6], lookAt: [0, 2.0, -1.0], fov: 42, rollDeg: -2.0, creep: 0.002 },
  { id: 'S10', aSec: 32.37, bSec: 34.37, set: 'bedroom', variant: 'bottle_closeup', palette: 'bedroom_night', camFrom: [1.4, 2.0, 4.4], camTo: [1.1, 1.85, 3.5], lookAt: [1.1, 1.65, -0.4], fov: 35, rollDeg: 3.0, creep: 0.004 },
  { id: 'S11', aSec: 34.37, bSec: 38.75, set: 'bedroom', variant: 'dosage_towers', palette: 'bedroom_night', camFrom: [-0.3, 2.3, 6.2], camTo: [0.2, 2.5, 5.4], lookAt: [0, 1.9, -0.4], fov: 40, rollDeg: -2.5, creep: 0.0025 },

  // ACT 3: Week 1 REM Storm (0:38.8 - 0:59.5)
  { id: 'S12', aSec: 38.75, bSec: 44.84, set: 'sleep_chart', variant: 'rem_dive', palette: 'purple_rem', camFrom: [0.0, 2.2, 6.6], camTo: [0.0, 1.8, 5.8], lookAt: [0, 1.8, 0], fov: 42, rollDeg: 1.5, creep: 0.002 },
  { id: 'S13', aSec: 44.84, bSec: 50.06, set: 'bedroom', variant: 'nightmare', palette: 'purple_rem', camFrom: [-0.4, 2.2, 5.6], camTo: [0.3, 2.1, 4.7], lookAt: [0, 1.8, 0], fov: 39, rollDeg: -4.2, creep: 0.0035 },
  { id: 'S14', aSec: 50.06, bSec: 54.27, set: 'bedroom', variant: 'alarm_7am', palette: 'morning_warm', camFrom: [1.0, 2.0, 5.0], camTo: [0.5, 1.9, 4.2], lookAt: [0.8, 1.65, -0.3], fov: 38, rollDeg: 3.5, creep: 0.003 },
  { id: 'S15', aSec: 54.27, bSec: 59.48, set: 'bedroom', variant: 'brain_fog', palette: 'morning_warm', camFrom: [-0.8, 2.2, 5.8], camTo: [0.4, 2.1, 5.0], lookAt: [0, 1.85, 0], fov: 40, rollDeg: -2.8, creep: 0.0025 },

  // ACT 4: Week 3 & Numb Receptors (0:59.5 - 1:17.1)
  { id: 'S16', aSec: 59.48, bSec: 61.73, set: 'lab_breaker', variant: 'week3_wall', palette: 'lab_tile', camFrom: [-0.8, 2.1, 5.8], camTo: [-0.2, 2.1, 4.9], lookAt: [0.3, 1.9, 0], fov: 40, rollDeg: 3.5, creep: 0.0035 },
  { id: 'S17', aSec: 61.73, bSec: 64.06, set: 'bedroom', variant: 'wide_awake_130am', palette: 'bedroom_night', camFrom: [0.0, 2.3, 5.4], camTo: [0.0, 2.2, 4.6], lookAt: [0, 1.85, 0], fov: 38, rollDeg: -2.0, creep: 0.003 },
  { id: 'S18', aSec: 64.06, bSec: 68.56, set: 'receptors', variant: 'docks_open', palette: 'receptor_tech', camFrom: [-0.9, 2.3, 6.4], camTo: [0.6, 2.2, 5.6], lookAt: [0, 1.8, 0], fov: 40, rollDeg: 2.0, creep: 0.002 },
  { id: 'S19', aSec: 68.56, bSec: 74.56, set: 'receptors', variant: 'docks_closing', palette: 'purple_rem', camFrom: [0.6, 2.2, 6.0], camTo: [-0.3, 2.1, 5.1], lookAt: [0, 1.8, 0], fov: 39, rollDeg: -3.2, creep: 0.0025 },
  { id: 'S20', aSec: 74.56, bSec: 75.57, set: 'receptors', variant: 'docks_numb', palette: 'receptor_tech', camFrom: [0.0, 2.1, 4.8], camTo: [0.0, 2.1, 4.3], lookAt: [0, 1.9, 0], fov: 36, rollDeg: 0.0, creep: 0.005 },
  { id: 'S21', aSec: 75.57, bSec: 77.15, set: 'bedroom', variant: 'second_gummy', palette: 'bedroom_night', camFrom: [-0.2, 2.2, 5.2], camTo: [0.2, 2.1, 4.5], lookAt: [0, 1.85, 0], fov: 37, rollDeg: 3.0, creep: 0.004 },

  // ACT 5: The 88% FDA Lab Audit (1:17.1 - 1:38.0)
  { id: 'S22', aSec: 77.15, bSec: 84.54, set: 'lab_breaker', variant: 'supplement_shelf', palette: 'lab_tile', camFrom: [-1.0, 2.2, 6.4], camTo: [0.8, 2.1, 5.7], lookAt: [0, 1.85, -0.5], fov: 41, rollDeg: -2.0, creep: 0.002 },
  { id: 'S23', aSec: 84.54, bSec: 87.63, set: 'lab_breaker', variant: 'fda_unverified', palette: 'lab_tile', camFrom: [0.6, 2.1, 5.4], camTo: [0.0, 2.0, 4.7], lookAt: [0, 1.8, -0.4], fov: 38, rollDeg: 2.5, creep: 0.003 },
  { id: 'S24', aSec: 87.63, bSec: 92.37, set: 'lab_breaker', variant: 'audit_88', palette: 'lab_tile', camFrom: [0.0, 2.2, 6.6], camTo: [0.0, 2.1, 5.8], lookAt: [0, 1.9, -0.6], fov: 42, rollDeg: -2.5, creep: 0.0025 },
  { id: 'S25', aSec: 92.37, bSec: 95.01, set: 'lab_breaker', variant: 'triple_dose', palette: 'lab_tile', camFrom: [-0.4, 2.1, 5.6], camTo: [0.2, 2.2, 4.8], lookAt: [0, 1.9, -0.4], fov: 39, rollDeg: 3.5, creep: 0.0035 },
  { id: 'S26', aSec: 95.01, bSec: 97.96, set: 'lab_breaker', variant: 'zero_cbd', palette: 'lab_tile', camFrom: [0.4, 2.1, 5.6], camTo: [-0.2, 2.1, 4.8], lookAt: [0, 1.9, -0.4], fov: 39, rollDeg: -3.0, creep: 0.0035 },

  // ACT 6: Starting Gun & Broken Rhythm (1:38.0 - 2:10.2)
  { id: 'S27', aSec: 97.96, bSec: 101.62, set: 'bedroom', variant: 'calendar_montage', palette: 'bedroom_night', camFrom: [-0.8, 2.3, 5.8], camTo: [0.6, 2.2, 5.0], lookAt: [0, 1.9, 0], fov: 40, rollDeg: 2.5, creep: 0.0028 },
  { id: 'S28', aSec: 101.62, bSec: 105.65, set: 'xray', variant: 'still_works', palette: 'xray_blue', camFrom: [0.0, 2.2, 5.8], camTo: [0.0, 2.2, 4.9], lookAt: [0, 2.0, 0], fov: 38, rollDeg: -1.5, creep: 0.0025 },
  { id: 'S29', aSec: 105.65, bSec: 108.27, set: 'bedroom', variant: 'clock_cracked', palette: 'bedroom_night', camFrom: [0.0, 2.4, 5.0], camTo: [0.0, 2.4, 4.1], lookAt: [0, 2.4, -2.5], fov: 36, rollDeg: 4.0, creep: 0.004 },
  { id: 'S30', aSec: 108.27, bSec: 111.49, set: 'lab_breaker', variant: 'starting_gun', palette: 'golden_track', camFrom: [-0.5, 2.2, 5.8], camTo: [0.3, 2.2, 4.9], lookAt: [0, 1.9, 0], fov: 39, rollDeg: -3.8, creep: 0.0035 },
  { id: 'S31', aSec: 111.49, bSec: 115.67, set: 'lab_breaker', variant: 'scrambled_track', palette: 'golden_track', camFrom: [0.7, 2.3, 6.2], camTo: [-0.6, 2.2, 5.4], lookAt: [0, 1.9, 0], fov: 41, rollDeg: 3.2, creep: 0.0025 },
  { id: 'S32', aSec: 115.67, bSec: 121.16, set: 'lab_breaker', variant: 'breaker_panel', palette: 'lab_tile', camFrom: [-0.4, 2.2, 5.8], camTo: [0.4, 2.1, 4.9], lookAt: [0, 2.0, -0.8], fov: 39, rollDeg: -2.2, creep: 0.0022 },
  { id: 'S33', aSec: 121.16, bSec: 126.38, set: 'bedroom', variant: 'split_midnight_2pm', palette: 'bedroom_night', camFrom: [0.0, 2.2, 6.4], camTo: [0.0, 2.1, 5.7], lookAt: [0, 1.85, 0], fov: 41, rollDeg: 1.8, creep: 0.002 },
  { id: 'S34', aSec: 126.38, bSec: 130.21, set: 'bedroom', variant: 'dizzy_cramps', palette: 'morning_warm', camFrom: [0.4, 2.1, 5.4], camTo: [-0.3, 2.0, 4.6], lookAt: [0, 1.8, 0], fov: 38, rollDeg: -3.5, creep: 0.003 },

  // ACT 7: The Irony, Reset & Moldy Food CTA (2:10.2 - 2:53.9)
  { id: 'S35', aSec: 130.21, bSec: 134.71, set: 'bedroom', variant: 'small_dose_scale', palette: 'golden_track', camFrom: [-0.4, 2.1, 5.6], camTo: [0.3, 2.0, 4.8], lookAt: [0, 1.75, -0.3], fov: 38, rollDeg: 1.5, creep: 0.0022 },
  { id: 'S36', aSec: 134.71, bSec: 139.35, set: 'bedroom', variant: 'two_hours_before', palette: 'golden_track', camFrom: [0.4, 2.3, 5.6], camTo: [-0.2, 2.3, 4.8], lookAt: [0, 2.1, -1.0], fov: 38, rollDeg: -1.8, creep: 0.0022 },
  { id: 'S37', aSec: 139.35, bSec: 141.77, set: 'sleep_chart', variant: 'jet_lag_plane', palette: 'golden_track', camFrom: [-0.8, 2.2, 6.0], camTo: [0.8, 2.2, 5.4], lookAt: [0, 2.0, 0], fov: 40, rollDeg: 2.2, creep: 0.0025 },
  { id: 'S38', aSec: 141.77, bSec: 146.16, set: 'xray', variant: 'healthy_green', palette: 'xray_blue', camFrom: [0.0, 2.2, 5.6], camTo: [0.0, 2.2, 4.8], lookAt: [0, 2.0, 0], fov: 38, rollDeg: -1.5, creep: 0.0022 },
  { id: 'S39', aSec: 146.16, bSec: 150.45, set: 'bedroom', variant: 'sunlight_reset', palette: 'sun_reset', camFrom: [-0.7, 2.2, 6.0], camTo: [0.4, 2.1, 5.1], lookAt: [0, 1.9, 0], fov: 40, rollDeg: 2.0, creep: 0.0025 },
  { id: 'S40', aSec: 150.45, bSec: 155.84, set: 'bedroom', variant: 'peaceful_sleep', palette: 'bedroom_night', camFrom: [0.5, 2.2, 5.8], camTo: [-0.3, 2.1, 5.0], lookAt: [0, 1.85, 0], fov: 39, rollDeg: -1.5, creep: 0.002 },
  { id: 'S41', aSec: 155.84, bSec: 163.69, set: 'lab_breaker', variant: 'moldy_bite', palette: 'kitchen_cta', camFrom: [-0.5, 2.2, 5.8], camTo: [0.2, 2.1, 4.7], lookAt: [0, 1.85, 0], fov: 38, rollDeg: 3.0, creep: 0.0028 },
  { id: 'S42', aSec: 163.69, bSec: 175.0, set: 'lab_breaker', variant: 'moldy_endcard', palette: 'kitchen_cta', camFrom: [0.0, 2.2, 6.2], camTo: [0.0, 2.1, 5.6], lookAt: [0, 2.0, 0], fov: 40, rollDeg: -1.2, creep: 0.0015 },
];

export const FLASH_SECS = [3.55, 59.48, 109.6];
export const KICK_SECS = [3.55, 7.2, 48.0, 59.48, 90.0, 109.6, 160.4];

export function smootherstep(t: number): number {
  const x = Math.max(0, Math.min(1, t));
  return x * x * x * (x * (x * 6 - 15) + 10);
}

export function getShotAt(frame: number): ShotBeat {
  const sec = frame / FPS;
  for (const s of SHOTS) {
    if (sec >= s.aSec && sec < s.bSec) return s;
  }
  return SHOTS[SHOTS.length - 1];
}

export function getKickOffset(frame: number): { dx: number; dy: number; dRoll: number } {
  let dx = 0;
  let dy = 0;
  let dRoll = 0;
  for (const ts of KICK_SECS) {
    const dt = frame - Math.round(ts * FPS);
    if (dt >= 0 && dt < 7) {
      const sign = dt % 2 === 0 ? 1 : -1;
      const decay = 1 - dt / 7;
      dx += sign * 0.22 * decay;
      dy += sign * 0.14 * decay;
      dRoll += sign * 3.2 * decay;
    }
  }
  return { dx, dy, dRoll };
}

export function cameraAt(frame: number) {
  const s = getShotAt(frame);
  const sec = frame / FPS;
  const u = smootherstep((sec - s.aSec) / Math.max(0.01, s.bSec - s.aSec));
  const local = frame - Math.round(s.aSec * FPS);
  const creep = 1 - Math.min(0.14, local * s.creep);
  const kick = getKickOffset(frame);

  return {
    pos: [
      s.camFrom[0] + (s.camTo[0] - s.camFrom[0]) * u + kick.dx,
      s.camFrom[1] + (s.camTo[1] - s.camFrom[1]) * u + kick.dy,
      s.camFrom[2] + (s.camTo[2] - s.camFrom[2]) * u,
    ] as [number, number, number],
    look: s.lookAt,
    fov: s.fov * creep,
    rollDeg: s.rollDeg + kick.dRoll,
  };
}
