import { PaletteKey } from './story';

export interface LightPalette {
  bg: string;
  fog: string;
  keyColor: string;
  keyIntensity: number;
  keyPos: [number, number, number];
  hemiSky: string;
  hemiGround: string;
  rimTint: string;
}

export const PALETTES: Record<PaletteKey, LightPalette> = {
  bedroom_night: {
    bg: '#1c2320',
    fog: '#1c2320',
    keyColor: '#ffdfa8',
    keyIntensity: 1.55,
    keyPos: [1, 6, 4],
    hemiSky: '#4e5f58',
    hemiGround: '#2b2019',
    rimTint: '#ffd898',
  },
  xray_blue: {
    bg: '#102436',
    fog: '#102436',
    keyColor: '#88dcff',
    keyIntensity: 1.4,
    keyPos: [3, 6, 5],
    hemiSky: '#3a78a8',
    hemiGround: '#122236',
    rimTint: '#7ee6ff',
  },
  morning_warm: {
    bg: '#8ca9c9',
    fog: '#b8cbe0',
    keyColor: '#fff2d8',
    keyIntensity: 1.6,
    keyPos: [8, 9, 6],
    hemiSky: '#a8c6e8',
    hemiGround: '#4a475c',
    rimTint: '#ffe8bc',
  },
  purple_rem: {
    bg: '#281544',
    fog: '#3d1f66',
    keyColor: '#e2a8ff',
    keyIntensity: 1.45,
    keyPos: [4, 7, 5],
    hemiSky: '#8a52c4',
    hemiGround: '#24143c',
    rimTint: '#e6b2ff',
  },
  receptor_tech: {
    bg: '#142636',
    fog: '#1a3246',
    keyColor: '#9cf4e6',
    keyIntensity: 1.5,
    keyPos: [4, 7, 6],
    hemiSky: '#5698a8',
    hemiGround: '#1a2434',
    rimTint: '#8ef6e8',
  },
  lab_tile: {
    bg: '#3f6e5c',
    fog: '#487664',
    keyColor: '#fff8e8',
    keyIntensity: 1.55,
    keyPos: [5, 8, 6],
    hemiSky: '#8cc4b0',
    hemiGround: '#344c44',
    rimTint: '#fff2d2',
  },
  golden_track: {
    bg: '#7d5a7c',
    fog: '#f0b67a',
    keyColor: '#ffb86e',
    keyIntensity: 1.65,
    keyPos: [2, 5, -10],
    hemiSky: '#ffc88e',
    hemiGround: '#443e6e',
    rimTint: '#ffcf98',
  },
  sun_reset: {
    bg: '#4b8ee0',
    fog: '#ffda9c',
    keyColor: '#fff3ce',
    keyIntensity: 1.75,
    keyPos: [8, 9, 4],
    hemiSky: '#98c8f8',
    hemiGround: '#54784c',
    rimTint: '#ffe9a8',
  },
  kitchen_cta: {
    bg: '#223e3a',
    fog: '#2c4c46',
    keyColor: '#e8f8dc',
    keyIntensity: 1.5,
    keyPos: [3, 7, 5],
    hemiSky: '#6ea496',
    hemiGround: '#22302c',
    rimTint: '#c8f8a8',
  },
};
