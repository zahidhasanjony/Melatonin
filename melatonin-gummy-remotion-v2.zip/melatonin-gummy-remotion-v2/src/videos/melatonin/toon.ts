/**
 * Upgraded v2 2D Character Drawing Engine (600x1000 canvas, feet at y=975).
 * Matches Your Brain's Secret Idea Zone / Ricks Clips craft:
 * - Layered brown hair with side part & soft highlight
 * - Bright ivory bean head (#f0efe9, h/w ~0.94) + dark plum ink (#241726)
 * - Collared striped pajamas / daytime sweater / track starter uniform
 * - Multi-pose articulated arms & props (eat, bottle, gun, sandwich, trash, stretch, slump)
 * - Expressive eyebrows, darting REM eyes, under-eye bags, sweat drop, dizzy stars
 */
export type HeroExpr = 'deadpan' | 'groggy' | 'sleep' | 'shock' | 'wide_awake' | 'happy' | 'rem_dart' | 'worry';
export type HeroOutfit = 'pajama' | 'day' | 'starter' | 'sunny';
export type HeroPose = 'rest' | 'eat' | 'bottle' | 'gun' | 'sandwich' | 'slump' | 'stretch' | 'sitting';

export interface DrawHeroV2Opts {
  expr: HeroExpr;
  outfit: HeroOutfit;
  pose: HeroPose;
  timeSec: number;
  isBlinking: boolean;
  dizzy?: boolean;
  sweat?: boolean;
  xrayMode?: boolean;
}

const INK = '#241726';
const FACE_IVORY = '#f2efe9';

export function drawHeroV2(ctx: CanvasRenderingContext2D, opts: DrawHeroV2Opts) {
  ctx.clearRect(0, 0, 600, 1000);
  const cx = 300;
  const bob = Math.sin(opts.timeSec * 3.2) * 10;
  const sitOffset = opts.pose === 'sitting' ? 70 : 0;
  const hipY = 675 - bob + sitOffset;

  ctx.save();
  ctx.strokeStyle = opts.xrayMode ? '#52c6ff' : INK;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  // Stick legs
  ctx.lineWidth = 15;
  ctx.beginPath();
  if (opts.pose === 'sitting') {
    ctx.moveTo(cx - 34, hipY);
    ctx.lineTo(cx - 54, hipY + 95);
    ctx.lineTo(cx - 48, 965);
    ctx.moveTo(cx + 34, hipY);
    ctx.lineTo(cx + 54, hipY + 95);
    ctx.lineTo(cx + 48, 965);
  } else {
    ctx.moveTo(cx - 32, hipY);
    ctx.lineTo(cx - 36, 968);
    ctx.moveTo(cx + 32, hipY);
    ctx.lineTo(cx + 36, 968);
  }
  ctx.stroke();

  // Bean torso with collar & outfit detail
  const torsoTop = 468 - bob + sitOffset;
  const torsoColors: Record<HeroOutfit, string> = {
    pajama: '#3f689e',
    day: '#3d7d78',
    starter: '#b83c38',
    sunny: '#de8738',
  };
  ctx.beginPath();
  ctx.roundRect(cx - 76, torsoTop, 152, 224, 62);
  ctx.fillStyle = opts.xrayMode ? 'rgba(62, 178, 245, 0.38)' : torsoColors[opts.outfit];
  ctx.fill();
  ctx.lineWidth = 11;
  ctx.stroke();

  // Shirt buttons / collar stripe (non-xray)
  if (!opts.xrayMode) {
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(cx, torsoTop + 26);
    ctx.lineTo(cx, torsoTop + 190);
    ctx.stroke();
    ctx.strokeStyle = INK;
  }

  // Stick arms + props
  const ay = torsoTop + 54;
  ctx.lineWidth = 14;
  ctx.beginPath();
  if (opts.pose === 'eat') {
    ctx.moveTo(cx - 72, ay);
    ctx.lineTo(cx - 118, ay + 95);
    ctx.moveTo(cx + 72, ay);
    ctx.lineTo(cx + 150, torsoTop - 20);
    ctx.stroke();
    // Glowing purple melatonin gummy
    ctx.beginPath();
    ctx.arc(cx + 158, torsoTop - 30, 22, 0, Math.PI * 2);
    ctx.fillStyle = '#c45cf8';
    ctx.fill();
    ctx.lineWidth = 7;
    ctx.stroke();
  } else if (opts.pose === 'bottle') {
    ctx.moveTo(cx - 72, ay);
    ctx.lineTo(cx - 112, ay + 90);
    ctx.moveTo(cx + 72, ay);
    ctx.lineTo(cx + 155, ay + 12);
    ctx.stroke();
    // Small purple bottle in hand
    ctx.fillStyle = '#7c36b8';
    ctx.fillRect(cx + 146, ay - 36, 42, 62);
    ctx.lineWidth = 6;
    ctx.strokeRect(cx + 146, ay - 36, 42, 62);
    ctx.fillStyle = '#f4f2ee';
    ctx.fillRect(cx + 152, ay - 52, 30, 16);
    ctx.strokeRect(cx + 152, ay - 52, 30, 16);
  } else if (opts.pose === 'gun') {
    ctx.moveTo(cx - 72, ay);
    ctx.lineTo(cx - 115, ay + 85);
    ctx.moveTo(cx + 72, ay);
    ctx.lineTo(cx + 165, ay - 75);
    ctx.stroke();
    ctx.fillStyle = '#383a44';
    ctx.fillRect(cx + 156, ay - 120, 22, 56);
    ctx.fillRect(cx + 156, ay - 126, 86, 26);
    ctx.lineWidth = 7;
    ctx.strokeRect(cx + 156, ay - 126, 86, 26);
  } else if (opts.pose === 'sandwich') {
    ctx.moveTo(cx - 72, ay);
    ctx.lineTo(cx - 115, ay + 85);
    ctx.moveTo(cx + 72, ay);
    ctx.lineTo(cx + 165, ay - 18);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx + 148, ay + 8);
    ctx.lineTo(cx + 252, ay + 8);
    ctx.lineTo(cx + 200, ay - 82);
    ctx.closePath();
    ctx.fillStyle = '#e5be78';
    ctx.fill();
    ctx.lineWidth = 8;
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx + 200, ay - 26, 28, 18, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#4ec448';
    ctx.fill();
    ctx.stroke();
  } else if (opts.pose === 'stretch') {
    ctx.moveTo(cx - 72, ay);
    ctx.lineTo(cx - 155, torsoTop - 75);
    ctx.moveTo(cx + 72, ay);
    ctx.lineTo(cx + 155, torsoTop - 75);
    ctx.stroke();
  } else {
    ctx.moveTo(cx - 72, ay);
    ctx.lineTo(cx - 114, ay + 95);
    ctx.moveTo(cx + 72, ay);
    ctx.lineTo(cx + 114, ay + 95);
    ctx.stroke();
  }

  // Bean head (h/w ~0.94, warm ivory white)
  const headY = torsoTop - 118;
  ctx.beginPath();
  ctx.ellipse(cx, headY, 122, 114, 0, 0, Math.PI * 2);
  ctx.fillStyle = opts.xrayMode ? 'rgba(62, 178, 245, 0.42)' : FACE_IVORY;
  ctx.fill();
  ctx.lineWidth = 11;
  ctx.stroke();

  if (opts.xrayMode) {
    // Glowing pink sculpted brain inside translucent blue X-ray head (Idea Zone style!)
    ctx.beginPath();
    ctx.ellipse(cx, headY - 12, 72, 54, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#f28ca8';
    ctx.fill();
    ctx.strokeStyle = '#5c2638';
    ctx.lineWidth = 7;
    ctx.stroke();
    // Neural spine wire
    ctx.strokeStyle = '#92ecff';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(cx, headY + 42);
    ctx.lineTo(cx, torsoTop + 180);
    ctx.stroke();
    ctx.restore();
    return;
  }

  // Layered brown hair with side part & subtle warm highlight (Idea Zone reference style!)
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, headY - 6, 124, Math.PI * 1.06, Math.PI * 1.94);
  ctx.quadraticCurveTo(cx + 55, headY - 46, cx + 18, headY - 68);
  ctx.quadraticCurveTo(cx - 48, headY - 40, cx - 122, headY - 26);
  ctx.closePath();
  ctx.fillStyle = '#5a3a22';
  ctx.fill();
  ctx.lineWidth = 10;
  ctx.strokeStyle = INK;
  ctx.stroke();
  // Hair highlight streak
  ctx.strokeStyle = '#7e5636';
  ctx.lineWidth = 10;
  ctx.beginPath();
  ctx.arc(cx - 12, headY - 12, 92, Math.PI * 1.25, Math.PI * 1.68);
  ctx.stroke();
  ctx.restore();

  // Eyes (0.26W apart = 64px)
  const eg = 32;
  const ey = headY + 6;
  ctx.fillStyle = INK;
  ctx.strokeStyle = INK;

  if (opts.isBlinking || opts.expr === 'sleep') {
    ctx.lineWidth = 8;
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(cx + d * eg - 18, ey);
      ctx.lineTo(cx + d * eg + 18, ey);
      ctx.stroke();
    }
  } else if (opts.expr === 'happy') {
    ctx.lineWidth = 8;
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.arc(cx + d * eg, ey + 6, 16, Math.PI * 1.1, Math.PI * 1.9);
      ctx.stroke();
    }
  } else if (opts.expr === 'shock' || opts.expr === 'wide_awake' || opts.expr === 'rem_dart') {
    const dartX = opts.expr === 'rem_dart' ? Math.sin(opts.timeSec * 14) * 7 : 0;
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.arc(cx + d * eg, ey, 19, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.lineWidth = 6.5;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx + d * eg + dartX, ey, 6.5, 0, Math.PI * 2);
      ctx.fillStyle = INK;
      ctx.fill();
    }
  } else {
    for (const d of [-1, 1]) {
      ctx.beginPath();
      ctx.ellipse(cx + d * eg, ey, 10.5, 12.5, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    if (opts.expr === 'deadpan' || opts.expr === 'groggy') {
      const lidH = opts.expr === 'groggy' ? 21 : 14;
      ctx.fillStyle = FACE_IVORY;
      ctx.fillRect(cx - eg - 18, ey - 16, eg * 2 + 36, lidH);
      ctx.lineWidth = 7;
      for (const d of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(cx + d * eg - 16, ey - 16 + lidH);
        ctx.lineTo(cx + d * eg + 16, ey - 16 + lidH);
        ctx.stroke();
      }
      if (opts.expr === 'groggy') {
        ctx.strokeStyle = '#9a84a8';
        ctx.lineWidth = 5;
        for (const d of [-1, 1]) {
          ctx.beginPath();
          ctx.arc(cx + d * eg, ey + 11, 14, 0.15 * Math.PI, 0.85 * Math.PI);
          ctx.stroke();
        }
        ctx.strokeStyle = INK;
      }
    }
  }

  // Expressive eyebrows
  ctx.lineWidth = 7;
  if (opts.expr === 'worry' || opts.expr === 'groggy') {
    ctx.beginPath();
    ctx.moveTo(cx - eg - 18, ey - 22);
    ctx.lineTo(cx - eg + 14, ey - 32);
    ctx.moveTo(cx + eg + 18, ey - 22);
    ctx.lineTo(cx + eg - 14, ey - 32);
    ctx.stroke();
  }

  // Mouth
  const my = headY + 52;
  ctx.lineWidth = 7.5;
  if (opts.expr === 'happy') {
    ctx.beginPath();
    ctx.arc(cx, my - 6, 26, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.closePath();
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.stroke();
  } else if (opts.expr === 'shock') {
    ctx.beginPath();
    ctx.ellipse(cx, my + 4, 16, 23, 0, 0, Math.PI * 2);
    ctx.fillStyle = INK;
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.moveTo(cx - 20, my);
    ctx.lineTo(cx + 20, my);
    ctx.stroke();
  }

  if (opts.sweat) {
    ctx.beginPath();
    ctx.moveTo(cx + 88, headY - 26);
    ctx.quadraticCurveTo(cx + 104, headY + 6, cx + 88, headY + 14);
    ctx.quadraticCurveTo(cx + 72, headY + 6, cx + 88, headY - 26);
    ctx.fillStyle = '#7ad6ff';
    ctx.fill();
    ctx.lineWidth = 5;
    ctx.stroke();
  }

  if (opts.dizzy) {
    for (let i = 0; i < 3; i++) {
      const ang = opts.timeSec * 4.2 + i * 2.094;
      const sx = cx + Math.cos(ang) * 110;
      const sy = headY - 125 + Math.sin(ang) * 20;
      ctx.beginPath();
      ctx.arc(sx, sy, 13, 0, Math.PI * 2);
      ctx.fillStyle = '#ffe05c';
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.stroke();
    }
  }

  ctx.restore();
}
