import * as THREE from 'three';

function makeCanvasTex(
  w: number,
  h: number,
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
  repX = 1,
  repY = 1
): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  draw(ctx, w, h);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repX, repY);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

/** Concentric brown/cream striped circular rug echoing Your Brain's Secret Idea Zone */
export function texStripedRug(): THREE.CanvasTexture {
  return makeCanvasTex(512, 512, (ctx, w, h) => {
    const cx = w / 2;
    const cy = h / 2;
    const colors = ['#4a2d1b', '#d9b583', '#6b4228', '#e5c99e', '#3c2214', '#cda572'];
    for (let i = 0; i < 6; i++) {
      const r = (w * 0.49) * (1 - i / 6);
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = colors[i];
      ctx.fill();
      ctx.strokeStyle = '#181010';
      ctx.lineWidth = 6;
      ctx.stroke();
    }
  });
}

/** Warm dark-wood planks with near-black seams */
export function texWoodPlanks(base = '#6f482b', repX = 3, repY = 3): THREE.CanvasTexture {
  return makeCanvasTex(
    512,
    512,
    (ctx, w, h) => {
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, w, h);
      const planks = 8;
      const ph = h / planks;
      for (let i = 0; i < planks; i++) {
        ctx.fillStyle = i % 2 === 0 ? 'rgba(0,0,0,0.08)' : 'rgba(255,220,170,0.06)';
        ctx.fillRect(0, i * ph, w, ph);
        ctx.fillStyle = '#160f0c';
        ctx.fillRect(0, i * ph, w, 4);
      }
    },
    repX,
    repY
  );
}

/** Japanese-office / lab green-brick tiled wall texture (The Job Nobody Wants in Japan style) */
export function texGreenTileWall(base = '#558b6e', mortar = '#1a2e25', repX = 3, repY = 2): THREE.CanvasTexture {
  return makeCanvasTex(
    512,
    512,
    (ctx, w, h) => {
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, w, h);
      const rows = 8;
      const rh = h / rows;
      for (let r = 0; r < rows; r++) {
        const shift = (r % 2) * 64;
        for (let c = -1; c < 5; c++) {
          const shade = ((r * 5 + c * 11) % 3) * 7 - 7;
          ctx.fillStyle = shade > 0 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)';
          ctx.fillRect(c * 128 + shift + 3, r * rh + 3, 122, rh - 6);
          ctx.strokeStyle = mortar;
          ctx.lineWidth = 4;
          ctx.strokeRect(c * 128 + shift + 2, r * rh + 2, 124, rh - 4);
        }
      }
    },
    repX,
    repY
  );
}

/** Framed silhouette wall portrait (Idea Zone bedroom detail) */
export function texWallPortrait(): THREE.CanvasTexture {
  return makeCanvasTex(256, 320, (ctx, w, h) => {
    ctx.fillStyle = '#c8aa78';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = '#4e311d';
    ctx.lineWidth = 24;
    ctx.strokeRect(12, 12, w - 24, h - 24);
    ctx.fillStyle = '#382a22';
    ctx.beginPath();
    ctx.arc(w / 2, h * 0.42, 42, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(w / 2, h * 0.78, 66, 52, 0, Math.PI, 0);
    ctx.fill();
  });
}

/** Crisp unlit sign / label texture (guaranteed centered with generous safe padding) */
export function texSign(
  title: string,
  subtitle = '',
  bg = '#f4ead8',
  fg = '#1c1420',
  accent = '#b83232'
): THREE.CanvasTexture {
  return makeCanvasTex(512, 256, (ctx, w, h) => {
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = '#140f18';
    ctx.lineWidth = 14;
    ctx.strokeRect(10, 10, w - 20, h - 20);
    ctx.fillStyle = fg;
    ctx.font = '900 58px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(title, w / 2, subtitle ? h * 0.38 : h * 0.5, w - 56);
    if (subtitle) {
      ctx.fillStyle = accent;
      ctx.font = '800 34px sans-serif';
      ctx.fillText(subtitle, w / 2, h * 0.7, w - 56);
    }
  });
}

/** Wall-mounted Circadian Breaker Panel texture (The Job Nobody Wants in Japan style) */
export function texBreakerPanel(switchesOn: boolean[]): THREE.CanvasTexture {
  return makeCanvasTex(512, 512, (ctx, w, h) => {
    ctx.fillStyle = '#2d333d';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = '#0e0c12';
    ctx.lineWidth = 14;
    ctx.strokeRect(8, 8, w - 16, h - 16);

    const labels = ['CORE TEMP', 'CORTISOL', 'SLEEP DRIVE', 'TIMING'];
    labels.forEach((lbl, idx) => {
      const col = idx % 2;
      const row = Math.floor(idx / 2);
      const x = 44 + col * 224;
      const y = 64 + row * 204;
      ctx.fillStyle = '#1b1e24';
      ctx.fillRect(x, y, 196, 168);
      ctx.strokeStyle = '#0b0a0c';
      ctx.lineWidth = 6;
      ctx.strokeRect(x, y, 196, 168);

      // Label plate
      ctx.fillStyle = '#e8c44c';
      ctx.fillRect(x + 16, y + 16, 164, 42);
      ctx.fillStyle = '#141218';
      ctx.font = '900 24px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(lbl, x + 98, y + 37);

      // Toggle switch + LED
      const on = switchesOn[idx] ?? false;
      ctx.fillStyle = on ? '#4ee47a' : '#ff4d4d';
      ctx.beginPath();
      ctx.arc(x + 158, y + 105, 13, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#cfd6e0';
      ctx.fillRect(x + 48, on ? y + 78 : y + 112, 64, 34);
      ctx.strokeRect(x + 48, on ? y + 78 : y + 112, 64, 34);
    });
  });
}
